<!-- Path: 08_GAME/PROJECT/BOOTSTRAP.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Project Bootstrap

## Autoload order
Register the following exact order in Project Settings: `WorldManager` → `GameStateManager` → `SaveSystem` → `InputManager` → `PerformanceMonitor`. Do not reorder these services without a documented dependency analysis and initialization test.

`WorldManager` owns world and scene loading. `GameStateManager` owns session state and legal transitions. `SaveSystem` validates and persists progression. `InputManager` normalizes controller and desktop actions. `PerformanceMonitor` gathers bounded diagnostics without blocking gameplay or introducing circular service dependencies.

The first scene should be a minimal bootstrap scene that confirms initialization, reports missing dependencies clearly, and provides a controlled exit path. Load heavy assets and terrain chunks on demand rather than forcing the complete catalog into memory at startup.

Acceptance requires opening the project in Godot 4.7.2, verifying service order, exercising initialization failure handling, and retaining logs. Until those checks run on the intended build, bootstrap status remains PLANNED or ACTIVE.
