<!-- Path: 08_GAME/PROJECT/scripts/LEIAME.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Scripts Directory

Use lowercase snake_case for GDScript filenames and stable English identifiers. Use `#` for comments; do not use `res` as a variable scope. Use `.duplicate()` when mutable arrays or dictionaries must not share state. Keep scripts focused, typed where useful, and covered by targeted tests.
