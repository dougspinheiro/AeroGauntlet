<!-- Path: 08_GAME/PROJECT/README.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Godot Project

The Godot project targets Godot 4.7.2 and Meta Quest 2. Keep scripts under `scripts/`, models under `assets/models/`, shaders under `assets/shaders/`, and automated checks under `tests/`. Folder names and code identifiers are English; player-facing strings use localization keys.

Terrain integration uses Chunked LOD Planet Cuberact under MIT terms, with required notices preserved. Third-party code must be isolated and tracked so license obligations and technical boundaries remain visible.

The project baseline is not validated until it opens in the declared engine, initializes the expected scene and services, and produces a retained test result. Desktop startup is useful for development but does not establish OpenXR or Quest 2 performance acceptance.
