<!-- Path: 08_GAME/PROJECT/INPUT_MAP.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Input Map

## Official actions
Define `pitch`, `roll`, `yaw`, `throttle`, `fire`, `brake`, `look`, and `menu` as stable logical actions. Gameplay systems consume logical actions rather than reading device-specific buttons directly. Normalize axis ranges and dead zones at the input boundary.

## Desktop fallback
Use W/S for pitch, A/D for roll, Q/E for yaw, arrow keys for secondary look or navigation as assigned, Space for fire, and R for brake or the explicitly documented brake binding. Avoid duplicate bindings that create ambiguous control behavior. The final mapping must be displayed in the control reference.

## Meta Quest 2
Map flight axes and weapon actions to supported controller inputs with adjustable handedness and clear confirmation. Include recenter and menu access without requiring uncomfortable reach. Do not assume every user uses the default grip or dominant hand.

Automated checks verify that all required actions exist and that bindings are not accidentally empty. Usability tests confirm that control labels match actual behavior in both PT-BR and English. Update documentation and localization tables together when bindings are changed.
