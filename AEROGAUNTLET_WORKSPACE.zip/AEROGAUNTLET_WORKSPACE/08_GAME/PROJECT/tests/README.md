<!-- Path: 08_GAME/PROJECT/tests/README.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Automated Tests

Run the headless Gauntlet Loop from the project environment with `godot --headless --path ./projeto_aerogauntlet --script res://tests/automation_qa.gd`. Confirm the executable resolves to Godot 4.7.2 and that the project path points to the intended checkout.

The automation should check project initialization, script parsing, required data fields, autoload availability, localization keys, save-schema validation, and deterministic core calculations. Each check reports a clear pass/fail result and returns a failing process status when a required gate fails.

Review `user://gauntlet_crash_report.log` after failure. Preserve the complete log, command, build identity, and environment details. Headless success does not validate headset comfort, rendering cost, or real-device frame pacing; those require a Quest 2 test session.
