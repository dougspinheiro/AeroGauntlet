<!-- Path: 05_AGENTES/AGENTES_ATIVOS.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: ACTIVE -->

# Active Agents

No agent is currently recorded as active. An agent becomes active only when assigned a bounded task with an owner, target paths, acceptance criteria, and a handoff deadline or completion condition.
