<!-- Path: 05_AGENTES/REGISTRO_AGENTES.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: ACTIVE -->

# Agent Register

No agent has been formally registered. New entries must include skill name, responsibility boundary, authority level, current assignment, dependencies, acceptance conditions, and status. Keep one canonical record per active role and retire assignments explicitly.
