<!-- Path: 04_CONHECIMENTO/ONBOARDING_E_TUTORIAL.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Onboarding and Tutorial

Teach core control mapping, aircraft attitude, throttle, energy management, target tracking, weapon use, and mission completion in small steps. Introduce concepts in context and avoid forcing the player to memorize a long control list before flying.

Provide era-specific tutorial missions that explain relevant aircraft behavior and weapons without assuming expertise. Each lesson needs a goal, a short instruction, an observable success condition, and a recovery path when the player fails.

Allow replay, pause, and control reference access. Keep voice and text synchronized, localizable, and concise. Tutorials must support seated play and remapped inputs rather than assuming one physical configuration.

Measure completion, repeated failures, abandonment points, and time to first successful objective. Treat findings as hypotheses to test, not as proof from a small sample.
