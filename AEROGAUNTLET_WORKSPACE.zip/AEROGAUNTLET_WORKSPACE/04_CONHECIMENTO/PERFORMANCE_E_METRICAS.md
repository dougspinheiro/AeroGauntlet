<!-- Path: 04_CONHECIMENTO/PERFORMANCE_E_METRICAS.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Performance and Metrics

Profile on Meta Quest 2 with release-like settings. Track CPU frame time, GPU frame time, frame pacing, memory/VRAM, draw calls, active aircraft, visible meshes, shader cost, and chunk streaming stalls. Record device temperature and scene conditions.

Operational targets are CPU 4–5 ms, GPU 5–6 ms, VRAM at or below 2.8 GB, and about 110 draw calls within an internal 10–11 ms frame budget. These budgets require repeated measurements and headroom for runtime variability.

Use controlled A/B captures for LOD, backface culling, AI cockpit removal, object pooling, texture compression, and shader simplification. A change is accepted only if measurements improve without breaking readability or behavior.

Keep raw logs, capture duration, build identity, test path, and analysis method. Distinguish median performance from worst-case spikes. Desktop profiles are useful for diagnosis but do not establish Quest 2 acceptance.
