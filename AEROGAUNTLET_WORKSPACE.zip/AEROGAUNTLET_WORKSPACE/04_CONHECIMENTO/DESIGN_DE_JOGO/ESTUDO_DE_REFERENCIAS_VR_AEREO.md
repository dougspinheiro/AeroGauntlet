<!-- Path: 04_CONHECIMENTO/DESIGN_DE_JOGO/ESTUDO_DE_REFERENCIAS_VR_AEREO.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# VR Aerial Game Reference Study

Review VTOL VR, Iron Wings, Flycatcher, Warplanes, Ultrawings 2, and Dawn of Jets as market references. Evaluate onboarding, flight readability, comfort options, mission variety, cockpit interaction, progression, visual communication, and platform positioning. The purpose is to identify user needs and design opportunities, not to reproduce protected content.

For each title, separate directly observed features from player-review claims and marketing statements. Record source, date, platform, price context, sample size, and confidence. A feature should not be labeled successful solely because it exists; look for repeated user feedback and observable design outcomes.

Translate findings into hypotheses for AeroGauntlet, such as whether a specific tutorial pattern reduces control errors or whether cockpit information density affects target acquisition. Validate hypotheses with prototype tests and player research before committing scope.
