<!-- Path: 04_CONHECIMENTO/LOCALIZACAO.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Localization

All player-facing strings support Brazilian Portuguese and English. Use Godot `tr()` keys and centralized translation tables; do not embed display text directly in gameplay logic. Keys are stable identifiers and should express purpose rather than the wording of one language.

Define placeholder names, pluralization rules, capitalization, punctuation, controller terminology, and fallback behavior. Preserve technical identifiers such as `WorldManager`, `PlaneData`, and input action names in English.

Test text expansion, line wrapping, font coverage, subtitles, cockpit labels, menus, briefings, and accessibility settings at actual headset viewing distance. Avoid relying on a single font for unsupported glyphs.

Automated checks must detect missing keys, duplicate identifiers, unused entries where practical, and invalid placeholders. The localization-engineer owns the key registry and reports any string that cannot fit the supported layout.
