<!-- Path: 04_CONHECIMENTO/ACESSIBILIDADE.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Accessibility

Provide color-independent signals for threats, objectives, damage, and weapon state. Use shape, icon, text, position, and audio redundancy rather than relying on hue alone. Test common color-vision deficiencies against real headset contrast and brightness.

Support seated play, adjustable cockpit height, recentering, left-handed controls, remappable inputs, and adjustable text size where the interaction model permits. Controls must not require prolonged overhead reach or uncomfortable neck rotation.

Comfort settings should include snap turning for menus or non-flight contexts, optional vignette where applicable, reduced artificial camera effects, and adjustable audio intensity. Explain each option clearly and preserve the player’s choice across sessions.

Accessibility acceptance is tested in both supported languages, at representative headset distances, and during high-workload combat. Track task completion and error rate, not only subjective visual inspection.
