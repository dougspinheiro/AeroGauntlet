<!-- Path: 04_CONHECIMENTO/AQUISICAO_DE_ASSETS_3D.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# 3D Asset Acquisition

Acquire models only from sources whose provenance and license terms can be documented. For the 321 manilov.ap aircraft, record the exact source URL, source identifier, retrieval date, license evidence, and any attribution requirements. A visible download link is not proof of redistribution rights.

Use Blender for inspection, cleanup, transform normalization, mesh separation, UV review, and export. Prefer GLB for the runtime pipeline when it preserves required materials and animation. Keep source files separate from optimized runtime exports and record tool settings for repeatability.

Meshy or other generation tools may be used only when the resulting asset is compatible with the historical scope and its commercial-use terms are understood. Generated content still requires silhouette review, scale checks, topology cleanup, and license/provenance records.

Each accepted model receives canonical naming, era, superclass, hash, texture budget, polygon count, material count, collision proxy, and LOD thresholds. Optimize hidden cockpit geometry out of AI-only aircraft and enable backface culling where geometry and material behavior allow.
