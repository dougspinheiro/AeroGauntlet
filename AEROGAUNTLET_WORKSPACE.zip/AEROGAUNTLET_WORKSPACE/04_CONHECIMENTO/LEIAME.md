<!-- Path: 04_CONHECIMENTO/LEIAME.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Knowledge Base

This directory contains technical guidance for asset acquisition, accessibility, VR interface design, localization, audio mixing, onboarding, performance measurement, and security/privacy. Documents define implementation constraints and acceptance checks; they do not imply that the corresponding systems have been implemented.

Use evidence-backed references, record uncertainty, and keep all recommendations aligned with the Operational Constitution.
