<!-- Path: 04_CONHECIMENTO/MIXAGEM_DE_AUDIO.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Audio Mixing

Prioritize immediate threats, player weapon feedback, engine state, mission-critical radio, and navigation cues. Every sound category needs an explicit priority and level range so combat effects do not mask essential information.

Use ducking to reduce lower-priority ambience during important radio messages or critical alerts. Define attack and release behavior to avoid abrupt level pumping. Mix must remain intelligible through the Quest 2 output path and common headphones.

Use a static, documented mixer layout with buses for engine, weapons, ambience, UI, and radio. Avoid creating buses dynamically during gameplay. Expose user settings for master volume and meaningful category controls.

Validate spatial cues, clipping, looping, localization of voice lines, and simultaneous-event stress. Audio processing cost and memory must be measured on target hardware; critical information must have a visual fallback.
