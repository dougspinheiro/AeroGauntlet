<!-- Path: 04_CONHECIMENTO/INTERFACE_E_UX_VR.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# VR Interface and UX

The HUD prioritizes flight safety, heading, airspeed, altitude, target direction, weapon state, and mission objectives. Place information in a stable, readable field of view without covering the horizon or target aircraft. Use redundant cues for critical alerts.

Menus use comfortable angular size, contrast, and interaction distance. Avoid forcing repeated head turns or long periods of arm extension. Confirm hover, selection, confirmation, cancellation, and error states for every interactive control.

Cockpit interaction must use stable hit targets and tolerant reach. Feedback should confirm successful input without relying on tiny text or subtle color changes. Physical cockpit controls and virtual menus must not compete for the same interaction priority.

Test seated and standing posture, left-handed configuration, recentering, tracking interruption, localization expansion, and worst-case visual clutter. Performance profiling must include HUD and cockpit materials.
