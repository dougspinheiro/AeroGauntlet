<!-- Path: 04_CONHECIMENTO/SEGURANCA_E_PRIVACIDADE.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Security and Privacy

Apply data minimization: collect only data required for save integrity, crash diagnosis, or explicitly disclosed product analytics. LGPD is Brazil’s General Data Protection Law; assess applicable duties, lawful basis, transparency, retention, and user rights rather than treating the acronym as a compliance certificate.

Validate save schemas and imported catalog metadata before use. Use atomic or recoverable writes, handle corruption without crashing, and keep credentials or secrets out of logs and local content. Do not execute scripts or content from untrusted assets.

Document the purpose, storage location, retention period, deletion behavior, and access path for any collected data. Prefer local diagnostics by default and require clear disclosure and appropriate consent for external telemetry.

Review third-party packages and asset licenses before distribution. Security claims must match implemented controls and tests; encryption should not be advertised unless the algorithm, key handling, and threat model have been reviewed.
