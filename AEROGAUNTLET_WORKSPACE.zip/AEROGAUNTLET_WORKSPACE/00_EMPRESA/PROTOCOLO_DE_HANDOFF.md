<!-- Path: 00_EMPRESA/PROTOCOLO_DE_HANDOFF.md
     Rank: Colonel
     Subordination: Operational Constitution + Human
     Status: FOUNDATIONAL -->

# Handoff Protocol

## Mandatory Header

- Emitting agent and rank
- Target directory and changed files
- Affected fleet/subsystems
- Performance target and available measurement
- Objective, decisions, tests, evidence, risks, and next step

## Pre-Submission Sanitization

1. Scan .gd files for // and review each occurrence.
2. Detect res used as scope or identifier.
3. Verify calls and need for .duplicate() on mutable structures. Run
   parser and tests when available.

## Context Break

Record confirmed state, executed commands, last result, blockers, and
safe next command. Do not reconstruct facts by assumption; consult
canonical files and logs.
