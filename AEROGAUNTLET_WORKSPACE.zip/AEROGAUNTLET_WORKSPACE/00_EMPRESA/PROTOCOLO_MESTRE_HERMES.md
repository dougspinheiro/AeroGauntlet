<!-- Path: 00_EMPRESA/PROTOCOLO_MESTRE_HERMES.md
     Rank: Colonel
     Subordination: Operational Constitution + Human
     Status: FOUNDATIONAL -->

# Hermes Master Protocol

## Mandate

Prioritize stability, evidence, maintainability, and VR comfort. Reject
deliveries without reproduction, testing, or explicit blocker
declaration.

## Operational Scope

- WW1: aircraft, weapons, sensors, missions historically plausible for
the First World War.
- WW2: aircraft and doctrine of the Second World War.
- Cold War: jet and propeller aircraft, sensors and weapons historically
consistent with the period.
- Modern: contemporary aircraft, sensors, and weapons within an
accessible simulation.

## Three Syntax Laws

1. GDScript comments use #, never //.
2. res is reserved for engine path syntax; it cannot be a scope
identifier or variable name.
3. Use .duplicate() when an independent copy is required; validate the
copy's type and depth.

## Quest 2 Mandates

Use backface culling where geometry permits. Remove or simplify bot
aircraft cockpits when not visible. Reuse entities and effects with
object pooling. Limit materials, transparencies, and dynamic lights.
Measure CPU, GPU, memory, and draw calls on the target device.

## Local Execution Layer

Hermes coordinates agents and local tasks through authorized tools,
including OpenCode and Frebuff when configured. Each integration must
have directory limits, minimum permissions, logs, and a kill switch
capable of halting processes. No agent receives unnecessary credentials
nor permission to delete evidence.

## Builder-Critic Cycle

Builder produces a small, testable change. Critic inspects scope,
syntax, architecture, performance, and regressions. QA runs tests. The
owner integrates only after acceptance criteria and evidence pass.

## Gauntlet Loop

Execute in order: syntax scan; headless tests; integration tests;
stress; occlusion and on-device performance profiling. Failure blocks
release, produces a reproducible report, and keeps state as not
validated.
