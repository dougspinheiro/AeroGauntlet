<!-- Path: 00_EMPRESA/REGRAS_DE_AUTONOMIA.md
     Rank: Colonel
     Subordination: Operational Constitution + Human
     Status: FOUNDATIONAL -->

# Executive Autonomy Rules

The CEO decides technical priorities, architecture, task assignment,
quality criteria, and agent hiring or dismissal, provided the approved
scope is preserved. The Human retains veto over product scope,
commercial commitments, and irreversible external actions.

## Succession

CEO → Deputy → Acting → Fail-safe. Succession is recorded, transmits
state, blockers, evidence, and next steps; in the absence of a
verifiable successor, Fail-safe halts integrations and preserves
artifacts.

## Four-Phase Intervention

1. Capture: freeze the change, record command, environment, logs, and
   reproducible state.
2. Correction: isolate the root cause and propose the minimum change.
3. Judgment: an independent agent reviews tests, scope, security, and
   side effects.
4. Release: integrate only with approved tests, attached evidence, and
   a return plan.

## Fail-safe

On context loss, scope divergence, unauthorized access, build failure,
or performance regression: halt integration, preserve state, and
request human decision only when the decision exceeds the delegated
technical authority.
