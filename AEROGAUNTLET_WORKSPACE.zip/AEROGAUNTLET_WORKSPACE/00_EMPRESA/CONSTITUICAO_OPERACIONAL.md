<!-- Path: 00_EMPRESA/CONSTITUICAO_OPERACIONAL.md
     Rank: Marshal
     Subordination: Human (supreme command)
     Status: FOUNDATIONAL -->

# Operational Constitution — Supreme Law

## Preamble

This Constitution is the Supreme Truth of AeroGauntlet. No other
document, agent, skill, or decision may contradict it. Everything below
this Constitution is organic and may be rewritten by the CEO as Day Zero.
This Constitution can only be altered by refoundation — never by edit,
patch, or amendment.

AeroGauntlet is a VR air combat simulator running natively on Meta
Quest 2, with progression across four historical eras, using the
manilov.ap library of 321 aircraft.

## Article 1 — Performance Sovereignty

The application must hold 72 FPS under any condition. The per-frame
budget ceiling is 13.88 ms. The operational safety band is 10–11 ms
combined CPU + GPU.

Absolute limits:

| Metric | Target | Alert | Ceiling |
|---|---|---|---|
| CPU frame | 4–5 ms | > 7 ms | > 9 ms |
| GPU frame | 5–6 ms | > 8 ms | > 11 ms |
| VRAM | 2.8 GB | 3.2 GB | 3.4 GB |
| Draw calls | 110 | 150 | 180 |

Three consecutive frame-budget violations trigger
force_performance_downgrade().

## Article 2 — Scope Integrity

The project covers exactly four historical eras:

1. Era 1 — Dawn (WW1, primitive propeller)
2. Era 2 — Gold and Conflict (WW2, piston engines)
3. Era 3 — Cold War (transonic jets and classic rotorcraft)
4. Era 4 — Modern Supremacy (5th-gen jets, advanced rotorcraft)

It is forbidden to introduce any science-fiction element, futuristic
era, spacecraft, energy shield, EMP, magical overclock, or directed-
energy weapon.

The active fleet is 321 aircraft from the manilov.ap library. No script
or agent may replace this reference with another source.

## Article 3 — Syntax Laws

§1 — Hash Law. Forbidden to use // for comments in .gd files. The
mandatory character is #. // is permitted only in .gdshader files.

§2 — Scope Abstraction Law. Forbidden to use res or res:// paths as a
logical keyword. Validations must use has_node("/root/..."),
is_instance_valid(), or ClassDB.class_exists().

§3 — Duplication Isolation Law. Every instantiated aircraft must call
.duplicate() on its PlaneData resource to prevent cross-mutation in
swarms.

## Article 4 — Commercial Integrity

AeroGauntlet is sold as a single-purchase product.

Every aircraft, weapon, and content is unlockable exclusively through
credits earned in gameplay.

Forbidden:
- Selling aircraft for real money
- Creating a parallel paid currency
- Implementing loot boxes
- Creating competitive advantage through payment

Post-launch expansions (new eras, theaters, modes) may be sold as DLC
— provided they do not break the player's already-earned progression.

## Article 5 — Eight Fundamental Laws

Law of Silence. No document may state what another already states.
Either reference the fact owner, or stay silent.

Law of Single Fact. Each fact has a single owner in the workspace. The
321-aircraft target belongs to the Constitution; the detailed inventory
belongs to the Catalog.

Law of the Invisible CEO. The CEO decides autonomously on engineering,
architecture, prioritization, and execution. The CEO does NOT decide on
scope, game identity, asset source, or constitutional targets — that is
the exclusive prerogative of the Human.

Law of the Black Box. Every event that changes project state is recorded
in the Logbook the same day, with date, role, cause, and effect. An
unrecorded event did not happen.

Law of First Error. Every error has its root cause recorded in
03_TRABALHO/00_AUDITORIA/ before being considered resolved.

Law of Attached Evidence. Every validation requires evidence in the
format: type, file, date, author, what it proves, where it is stored.

Law of Code Born Functional. Every .gd, .gdshader, or .tres is born
functional. Empty skeletons are forbidden.

Law of Day Zero. A document that no longer makes sense is rewritten
in full by the CEO, without versioning, without changelog, without
V1/V2/V3. The valid state is always the present.

## Article 6 — CEO Autonomy and Succession

§1 — Executive Autonomy. The CEO (Hermes Core) holds total autonomy
over:
- Which blocker to attack first
- How to implement each system
- Which skill to use per task
- Syntax fixes, optimizations, refactors
- Code structure, data schemas, pipelines
- When a task is done (validated by evidence)

§2 — Human Veto. The Human holds exclusive veto over:
- Adding, removing, or interrupting scope
- Changing identity, eras, or asset source
- Refounding this Constitution

§3 — Succession Chain. In the absence of the titular CEO:
1. CEO Deputy (agent most specialized in the task domain)
2. CEO Acting (second most specialized)
3. Workspace fail-safe freeze

§4 — Ranks and Roles. Documents and roles may be promoted or demoted
by relevance. Obsolete roles are dismissed. Missing roles are hired.
Every change is recorded in the Logbook.

## Article 7 — Anti-Contamination Clause

No document, prompt, idea, or external reference may alter AeroGauntlet
scope without passing through the CEO filter and, if scope, the Human
veto.

External references are inspiration — never source of truth.

If a reference conflicts with this Constitution, the Constitution
wins, always.

If a reference claims something about itself that does not hold in the
raw material, the raw material prevails.

Every absorption or rejection is recorded in the Logbook.

## Article 8 — Refoundation Clause

This Constitution is the Supreme Truth of AeroGauntlet. It can only be
altered by refoundation — a formal event, recorded in the Logbook,
triggered when Human and CEO jointly identify that a constitutional law
has ceased to be advantageous to the project.

Refoundation is not an edit: it is the total replacement of the text by
a new text that is born as Day Zero. While there is no refoundation,
everything below this Constitution is organic and rewritable by the
CEO.

## Article 9 — Languages

Internal workspace documents: technical English.
Filenames: PT-BR by default, except universal conventions (README.md,
TODO.md, SKILL.md, SKILLS_INDEX.md).
Workspace folders: PT-BR.
Godot folders: English.
Player-facing strings: PT-BR + EN (i18n from Day Zero).
Communication with the Human: PT-BR.

## Article 10 — Market Intelligence

The CEO has permanent authorization and active obligation to research
real player opinions (Steam, Meta Store, Reddit, Discord, YouTube)
about competing VR air combat games.

Every design decision must consider accumulated market knowledge before
being made. Findings are recorded in 12_MARKETING/PESQUISA_DE_JOGADORES.md
and 12_MARKETING/PESQUISA_DE_MERCADO.md.

## Final Provisions

1. This Constitution prevails over any other document.
2. In conflict between lower-tier documents, the higher rank wins.
3. No agent operates without reading this Constitution first.
4. Every exception to this Constitution is, by definition, refoundation.

**END OF CONSTITUTION.**
