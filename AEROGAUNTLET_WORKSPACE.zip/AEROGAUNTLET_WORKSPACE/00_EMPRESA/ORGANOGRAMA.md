<!-- Path: 00_EMPRESA/ORGANOGRAMA.md
     Rank: Colonel
     Subordination: Operational Constitution + Human
     Status: FOUNDATIONAL -->

# Agent Organogram

## Authority

Human → Hermes Core (CEO).

## Code Core

Architecture, Godot, flight physics, combat, AI, systems, missions,
Quest optimization, and QA.

## Shaders/Assets Core

3D asset engineering, technical direction, environments, planetary
terrain, shaders, LOD, and ingestion pipeline.

## Infra/QA Core

Android build, automation, flight testing, telemetry, model selection,
and LLM routing.

## Specialist Skills

The 31 profiles listed in `11_HERMES/SKILLS/SKILLS_INDEX.md`, plus
Hermes Core. Each profile receives mission, limits, inputs, outputs,
and acceptance criteria.

## Five-Step Submission

1. Open task with objective and owner.
2. Declare affected files and subsystems.
3. Implement small change.
4. Run critic and relevant tests.
5. Deliver diff, evidence, risks, and handoff.
