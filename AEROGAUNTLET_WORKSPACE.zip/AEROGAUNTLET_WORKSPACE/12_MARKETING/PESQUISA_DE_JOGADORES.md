<!-- Path: 12_MARKETING/PESQUISA_DE_JOGADORES.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Player Research

Analyze public reviews and player discussions for recurring praise, friction, and unmet expectations. Common coding dimensions include controls, flight feel, comfort, performance, content variety, mission quality, progression, onboarding, and price-value perception.

Do not treat an individual review as representative. Record platform, date, review context, sample size, and whether a statement is a direct observation, personal preference, or reproducible defect report. Cluster themes by frequency and severity.

Convert patterns into testable hypotheses. For example, reports of confusing controls should lead to an onboarding usability test; reports of discomfort should lead to controlled comfort testing and session-duration analysis.

Share findings without exposing personal data. Include counterexamples, confidence, and recommended experiments so product decisions do not overfit to the loudest comments.
