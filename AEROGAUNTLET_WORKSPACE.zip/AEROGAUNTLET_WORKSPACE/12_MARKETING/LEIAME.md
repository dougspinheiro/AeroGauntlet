<!-- Path: 12_MARKETING/LEIAME.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Marketing Workspace

This directory contains visual identity, positioning, launch planning, promotional asset requirements, market research, and player research. Treat all market statements as time-sensitive and cite sources with access dates. Separate planned features from verified shipped capabilities.
