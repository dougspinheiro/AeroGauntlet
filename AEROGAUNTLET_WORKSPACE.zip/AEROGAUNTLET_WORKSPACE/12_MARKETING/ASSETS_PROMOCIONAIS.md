<!-- Path: 12_MARKETING/ASSETS_PROMOCIONAIS.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Promotional Assets

The promotional package includes a gameplay trailer, clean screenshots, store capsule art, key art, short clips, and concise feature descriptions. Capture footage from a representative build and disclose when imagery is pre-rendered rather than real-time gameplay.

The trailer should establish aircraft control, combat readability, era range, cockpit presence, and mission stakes quickly. Avoid visual effects that obscure the actual product or imply systems outside the four authorized eras.

Screenshots should show genuine gameplay, clear aircraft silhouettes, legible HUD elements, and varied historical settings. Each image must be reviewed for visual defects, incorrect equipment, placeholder text, and misleading performance claims.

Maintain source files, usage rights, crop variants, captions, language variants, and final export settings. Do not use third-party aircraft imagery without documented rights and attribution where required.
