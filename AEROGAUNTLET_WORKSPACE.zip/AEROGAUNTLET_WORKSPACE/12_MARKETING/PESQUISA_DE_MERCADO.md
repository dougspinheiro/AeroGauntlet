<!-- Path: 12_MARKETING/PESQUISA_DE_MERCADO.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Market Research

Benchmark VTOL VR, Iron Wings, Flycatcher, Warplanes, Ultrawings 2, and Dawn of Jets across platform, price, flight model, combat depth, cockpit interaction, mission design, progression, comfort, and content breadth. Capture source URLs and access dates for changing facts.

Separate observable product features from inferred strategy. Record feature presence, quality evidence, user segment, and confidence. Pricing comparisons must specify platform, currency, discount status, and capture date so unlike offers are not treated as equivalent.

Look for unmet needs such as clearer onboarding, reliable comfort options, historically coherent aircraft variety, stable standalone performance, and transparent unlock progression. These are hypotheses to test, not automatic commitments.

Deliver a concise competitor matrix, source register, differentiated positioning options, and recommended player tests. Never copy distinctive protected assets, text, mission scripts, or branding.
