<!-- Path: 12_MARKETING/POSICIONAMENTO.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Market Positioning

AeroGauntlet is positioned as a VR aerial combat simulator spanning four historical eras, with a planned catalog of 321 aircraft from manilov.ap subject to licensing and integration validation. The central value proposition is aircraft variety, readable combat, and hands-on cockpit presence.

The commercial model is a single purchase. Aircraft unlock through gameplay credits, and the base game must not sell competitive power. Optional DLC may be offered after MVP with transparent content descriptions and no pay-to-win advantages.

Messaging should distinguish intended scope from shipped, verified content. Do not claim that all 321 aircraft are available until every item passes provenance, license, optimization, and integration gates. Do not claim a stable 72 FPS without target-device evidence.

Positioning is tested through store-page experiments, player interviews, review analysis, and conversion metrics. Competitive references include VTOL VR, Iron Wings, Flycatcher, Warplanes, Ultrawings 2, and Dawn of Jets; analysis must identify gaps rather than copy presentation or protected features.
