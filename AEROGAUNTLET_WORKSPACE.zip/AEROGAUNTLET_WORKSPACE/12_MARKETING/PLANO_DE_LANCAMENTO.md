<!-- Path: 12_MARKETING/PLANO_DE_LANCAMENTO.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Launch Plan

Use gated release stages: internal alpha, closed beta, Early Access, and 1.0. Each stage has explicit stability, content, performance, accessibility, and feedback criteria. Progression between stages depends on evidence, not calendar pressure alone.

Potential channels include Meta Store, Steam, and SideQuest, subject to platform requirements and product readiness. Prepare distinct metadata, package formats, screenshots, compatibility statements, age ratings, privacy disclosures, and support processes for each channel.

Alpha focuses on core flight, combat, crashes, and frame pacing. Beta adds broader aircraft and mission coverage, localization checks, and player research. Early Access requires a reliable progression loop, transparent roadmap, save integrity, and a clear account of known gaps. Version 1.0 requires release-candidate QA, signed builds, license clearance, and support readiness.

Track crash-free sessions, frame-budget pass rate, tutorial completion, mission completion, refund reasons, and recurring review themes. Protect player privacy and publish only claims that can be supported by recorded evidence.
