<!-- Path: 12_MARKETING/IDENTIDADE_VISUAL.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: PLANNED -->

# Visual Identity

The AeroGauntlet identity should communicate aerial combat, aircraft mastery, precision, and historical range. Visual language must remain credible across WW1, WW2, Cold War, and Modern eras without allowing one era’s equipment to dominate the entire brand.

Use a disciplined palette built around high-contrast aviation instrumentation, neutral metal tones, and restrained era-specific accents. Typography must remain readable at small store-thumbnail sizes and on headset-facing UI. Avoid decorative detail that weakens title recognition.

Voice is direct, technical, confident, and accessible to both aviation enthusiasts and VR newcomers. Claims about aircraft count, frame rate, realism, and compatibility must be qualified by verified evidence and actual release scope.

Every campaign asset must preserve title treatment, logo safe area, legibility, and consistent color behavior. Create a documented asset package with approved fonts, colors, logo variants, and usage examples.
