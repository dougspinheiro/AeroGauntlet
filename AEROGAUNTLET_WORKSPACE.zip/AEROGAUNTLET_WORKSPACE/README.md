<!-- Path: README.md
     Rank: Marshal
     Subordination: Operational Constitution + Human
     Status: FOUNDATIONAL -->

# AeroGauntlet — Workspace

VR air combat simulator. Godot 4.7.2. Meta Quest 2 native at 72 FPS.

## Structure

- `00_EMPRESA/` — constitutional governance and operating protocols
- `01_MESTRE/` — master design and specification document
- `02_ESTADO/` — current real state of the project
- `03_TRABALHO/` — backlog, blockers, roadmap, decisions, audits
- `04_CONHECIMENTO/` — knowledge base by domain
- `05_AGENTES/` — agent registry and handoffs
- `06_DIARIO/` — black-box development log
- `07_ASSETS/` — asset catalog and ingestion pipeline
- `08_GAME/` — actual Godot project
- `09_BUILD/` — builds and build checklist
- `10_ARQUIVO/` — archived versions and evidence
- `11_HERMES/SKILLS/` — 31 specialist agent skill definitions
- `12_MARKETING/` — identity, positioning, launch
- `13_GLOSSARIO/` — canonical vocabulary

## Golden Rule

No file in this workspace represents completed work merely because it
exists. Completion = opens in Godot without error + real evidence
attached. See `00_EMPRESA/CONSTITUICAO_OPERACIONAL.md`.

## Mandatory Reading Order (for any new agent)

1. `00_EMPRESA/CONSTITUICAO_OPERACIONAL.md`
2. `00_EMPRESA/INDICE_DE_DOCUMENTOS.md`
3. `01_MESTRE/DOCUMENTO_MESTRE_UNIFICADO.md`
4. `02_ESTADO/ESTADO_ATUAL.md`
5. `06_DIARIO/DIARIO_DE_BORDO.md`
6. `03_TRABALHO/TODO.md`

No action is taken without completing the reading order above.
