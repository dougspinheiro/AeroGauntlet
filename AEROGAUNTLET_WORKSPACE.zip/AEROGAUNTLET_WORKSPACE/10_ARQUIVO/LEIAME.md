<!-- Path: 10_ARQUIVO/LEIAME.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Archive Policy

Preserve superseded artifacts rather than deleting them when they are needed to explain a formal decision or reproduce a result. Every archived item must include its path, reason for replacement, date, owner, and dependencies. Archive notes are operational records, not a changelog. Keep the current canonical document clearly identifiable and do not restore an archived artifact without an explicit decision.
