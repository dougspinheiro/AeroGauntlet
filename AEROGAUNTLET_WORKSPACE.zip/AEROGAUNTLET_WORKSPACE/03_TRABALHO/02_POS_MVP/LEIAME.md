<!-- Path: 03_TRABALHO/02_POS_MVP/LEIAME.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Post-MVP Workspace

This directory holds proposals for work considered after MVP acceptance. Proposals must state scope, dependencies, cost, risk, compatibility, and measurable acceptance criteria. Post-MVP ideas do not authorize changes to the four-era scope or the single-purchase, no-pay-to-win commercial model.
