<!-- Path: 03_TRABALHO/ESTRATEGIA_DE_TESTES.md
     Rank: Captain
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: ACTIVE -->

# Test Strategy

**Unit tests** validate isolated calculations and data rules: force components, weapon limits, unlock costs, localization key lookup, and save schema validation. Run them on every relevant change and keep test inputs deterministic.

**Integration tests** verify contracts between autoloads, Resources, missions, input, save/load, and terrain streaming. **Smoke tests** confirm that the project opens, initializes services, loads a minimal scene, and exits without critical errors. Run smoke tests for every integrated build.

**Regression tests** reproduce fixed defects and protect previously accepted behavior. Add a regression case whenever a defect is reproducible and automatable. **Stress tests** target peak aircraft counts, projectiles, world chunks, repeated scene transitions, and long sessions; run them before performance gates and release candidates.

The headless Gauntlet Loop is the supreme automated tribunal for syntax and scripted checks, invoked with `godot --headless --path ./projeto_aerogauntlet --script res://tests/automation_qa.gd`. Review `user://gauntlet_crash_report.log`. Headless success does not validate headset comfort, OpenXR behavior, or real-device frame pacing; those require Quest 2 evidence.
