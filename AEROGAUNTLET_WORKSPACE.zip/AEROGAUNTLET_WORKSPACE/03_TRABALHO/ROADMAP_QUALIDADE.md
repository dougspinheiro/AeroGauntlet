<!-- Path: 03_TRABALHO/ROADMAP_QUALIDADE.md
     Rank: Captain
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: ACTIVE -->

# Quality Roadmap

## Absolute operational targets
- CPU: 4–5 ms per frame.
- GPU: 5–6 ms per frame.
- VRAM: maximum 2.8 GB.
- Draw calls: approximately 110.
- Target: Meta Quest 2, sustained 72 FPS, internal frame budget 10–11 ms.

These values are acceptance targets, not claims about current performance. Measure on the target headset using representative scenes, controlled build settings, and recorded thermal conditions.

## Gauntlet Loop stages
1. **Syntax sweep:** scan `.gd` files for `//`, invalid `res` scope use, missing `.duplicate()` at mutation boundaries, parse failures, and unresolved resource paths.
2. **Stress test:** exercise peak aircraft counts, projectiles, effects, chunk loading, mission transitions, and save/load paths. Record crashes, stalls, memory peaks, and test duration.
3. **Occlusion profiling:** capture draw calls, visible objects, GPU time, overdraw, and LOD transitions with controlled camera paths. Compare changes against a recorded baseline.

## Fail-safe
If a critical crash, data corruption, license defect, or sustained budget breach appears, stop the affected release path, preserve logs, revert or isolate the offending change, and require a fresh acceptance run. No performance claim is accepted without reproducible evidence.
