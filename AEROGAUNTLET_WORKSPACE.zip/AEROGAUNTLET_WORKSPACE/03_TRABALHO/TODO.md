<!-- Path: 03_TRABALHO/TODO.md
     Rank: Captain
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: ACTIVE -->

# Work Backlog

## P0 — Blocking foundations
- **B01 — Ingest 321 IDs:** register every manilov.ap source ID, URL, canonical name, era, superclass, license status, hash, and ingestion state. Acceptance: all rows exist and unknown licensing is visibly blocked.
- **B02 — Dual flight physics:** implement separate fixed-wing and rotary-wing dynamics, including collective, cyclic, anti-torque, and ground effect for rotorcraft. Acceptance: deterministic tests cover controls, stalls, and stability boundaries.
- **B03 — Shader uniforms:** declare and validate shader uniforms with defaults and ranges. Acceptance: all initial shader families compile and pass Quest 2 profiling.

## P1 — Quest optimization
Measure backface culling, AI cockpit removal, object pooling, LOD thresholds, texture compression, draw calls, CPU/GPU time, and memory. Accept only changes supported by before/after measurements on representative scenes.

## P2 — Era-specific armament
Populate weapon data for WW1 machine guns, WW2 machine guns and cannons, Cold War infrared missiles, and Modern radar-guided BVR missiles. Validate aircraft compatibility and historical constraints.

## P3 — Archival and maintenance
Preserve source licenses, build reports, acceptance evidence, and retired artifacts according to archive policy. Avoid deleting evidence needed to reproduce decisions.
