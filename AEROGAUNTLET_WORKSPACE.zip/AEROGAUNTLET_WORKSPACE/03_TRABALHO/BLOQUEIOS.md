<!-- Path: 03_TRABALHO/BLOQUEIOS.md
     Rank: Captain
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: ACTIVE -->

# Blocking Issues

## B01 — Missing catalog registration
**Description:** the 321 manilov.ap source IDs are not yet represented by a verified, complete catalog. **Impact:** aircraft ingestion, license compliance, progression, and release scope cannot be audited. **Required resolution:** record source URL, source ID, canonical ID, era, superclass, license evidence, hash, state, and notes for every item. Unknown license status remains blocked.

## B02 — Dual flight dynamics absent
**Description:** fixed-wing and rotary-wing aircraft require distinct force and control models. **Impact:** shared simplified logic would misrepresent rotor controls and invalidate flight testing. **Required resolution:** implement separate models, define units and parameter ranges, and attach repeatable tests for handling, stall, hover, cyclic response, anti-torque, and ground effect.

## B03 — Shader uniform contracts incomplete
**Description:** shader parameters lack a complete declared interface or verified defaults. **Impact:** materials may render inconsistently, fail to compile, or exceed the GPU budget. **Required resolution:** declare uniforms at the top, validate types and ranges, test all shader families, and capture Quest 2 GPU profiles.

A blocker closes only when the required evidence is attached, the acceptance condition passes, and the current-state table identifies the tested build and environment.
