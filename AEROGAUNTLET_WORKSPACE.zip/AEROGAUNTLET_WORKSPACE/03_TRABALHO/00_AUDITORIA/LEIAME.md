<!-- Path: 03_TRABALHO/00_AUDITORIA/LEIAME.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Audit Workspace

This directory holds audit-specific planning and evidence. Record the tested artifact, environment, commands, observed result, and evidence location. An audit conclusion is valid only for the scope actually tested; unresolved findings remain explicit blockers.
