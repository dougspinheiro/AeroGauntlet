<!-- Path: 03_TRABALHO/DECISOES_PENDENTES.md
     Rank: Captain
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: ACTIVE -->

# Decision Register

## Decision template
- **ID:** unique identifier.
- **Question:** the concrete decision required.
- **Owner:** accountable role.
- **Options:** viable alternatives and trade-offs.
- **Constraints:** constitutional, technical, legal, and schedule boundaries.
- **Evidence:** tests, measurements, sources, or market observations.
- **Decision:** selected option and rationale.
- **Consequences:** affected files, interfaces, risks, and follow-up work.
- **Status:** OPEN, DECIDED, or BLOCKED.

## Initial register
No unresolved engineering decision is asserted without a recorded entry. The following technical work is planned rather than accepted: confirm the Godot project baseline, establish Resource schemas, implement fixed-wing and rotary-wing physics, complete asset provenance records, and validate Quest 2 performance. These are backlog items, not implicit decisions.

Record a decision before implementing a change that affects shared schemas, service contracts, licensing, performance budgets, save compatibility, or content scope. The CEO may decide engineering matters autonomously; scope, identity, asset-source, and constitutional-target changes require the Human.
