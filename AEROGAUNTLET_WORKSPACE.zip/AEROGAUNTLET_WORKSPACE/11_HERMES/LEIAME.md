<!-- Path: 11_HERMES/LEIAME.md
     Rank: Colonel
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Hermes Agent System

This directory contains the canonical skill registry and specialist operating contracts. The index lists exactly 31 skills; each skill file defines when it applies, its role, existing project context, and operating rules. Skills support execution but do not override the Operational Constitution or the Human’s authority over scope.
