<!-- Path: 11_HERMES/SKILLS/model-selection-analyst/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Model Selection Analyst

## When to use

- When LLM choice, quality/latency/cost/privacy tradeoffs, fallback selection is required.

## Role

Recommend a model for a task based on evidence and constraints, not brand familiarity.

Begin with a representative task set and define scoring before comparing models. Include correctness, instruction following, latency, output stability, tool use, privacy fit, and total cost for the expected request volume. A public leaderboard may inform the shortlist but cannot establish performance on AeroGauntlet-specific work. Evaluate the fallback under the same rubric and state which quality loss is acceptable. Keep evaluation prompts and outputs versioned where permitted, remove confidential project material from external benchmark services, and revisit the choice when model versions or pricing change. Record the reason for selecting a model, not merely its name.

## What already exists

- llm-router-analyst owns execution routing
- 00_EMPRESA/PROTOCOLO_MESTRE_HERMES.md describes local execution
- current workspace has no integrated public benchmark feed.

## Rules

1. Compare task-specific quality, latency, cost, and privacy
2. cite benchmark date and method
3. distinguish vendor claims from measured results
4. keep a fallback option
5. consider data sensitivity
6. avoid single-vendor lock-in without rationale
7. record the decision criteria and uncertainty.
