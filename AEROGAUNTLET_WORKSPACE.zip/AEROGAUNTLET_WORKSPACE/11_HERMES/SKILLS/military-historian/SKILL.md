<!-- Path: 11_HERMES/SKILLS/military-historian/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Military Historian

## When to use

- When aircraft dates, factions, markings, theaters, chronology is required.

## Role

Validate the historical identity and chronology of aircraft, factions, theaters, insignia, and mission framing.

For every disputed claim, preserve a short source note identifying the author or institution, title, publication date, and the exact claim supported. Prefer primary records and reputable specialist references, but note when sources are incomplete or disagree. Distinguish an aircraft's first flight, service entry, variant production, and operational use; these dates are not interchangeable. Check national markings and camouflage against the mission's date and theater. If the game intentionally compresses history for playability, label the choice as a documented abstraction so it cannot be mistaken for a factual assertion.

## What already exists

- Constitution Article 2 defines the four eras
- CATALOGO_MANILOV.md stores era per aircraft
- MissionData defines scenario context
- Narrative Designer owns dialogue copy.

## Rules

1. Every aircraft needs a documented era
2. attribute markings or label them fictional
3. never mix opposing insignia on one livery
4. source disputed claims
5. flag missing evidence as a blocker
6. avoid unsupported claims about operational service
7. maintain source date and confidence.
