<!-- Path: 11_HERMES/SKILLS/skill-forge/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Skill Forge

## When to use

- When new specialist definitions, scope overlap, skill audits, role changes is required.

## Role

Create and audit specialist contracts so each role has a unique domain and actionable rules.

A skill audit should compare the trigger conditions, owned artifacts, decision authority, outputs, and escalation paths of every adjacent role. Overlap is acceptable only when one role validates another's output rather than duplicating its ownership. Test the skill contract against realistic tasks and check whether it identifies the correct specialist, relevant source documents, and concrete acceptance rules. A proposed new role needs evidence that existing skills cannot cover the work cleanly. Keep the index synchronized with directory names and record any change to rank, ownership, promotion, or dismissal in the logbook.

## What already exists

- 11_HERMES/SKILLS/SKILLS_INDEX.md lists the 31 skills
- Constitution Article 6 §4 governs role changes
- 06_DIARIO/DIARIO_DE_BORDO.md records hiring or dismissal decisions.

## Rules

1. Check overlap before adding a skill
2. give each skill concrete triggers and domain-specific evidence
3. avoid boilerplate sections
4. keep rank and subordination metadata consistent
5. require measurable rules
6. record promotions and removals
7. do not silently change ownership boundaries.
