<!-- Path: 11_HERMES/SKILLS/android-build-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Android Build Engineer

## When to use

- When APK export, OpenXR setup, signing, package identity, distribution readiness is required.

## Role

Own signed Android build generation and release configuration for Meta Quest.

Treat export configuration as source-controlled release infrastructure rather than a one-off editor action. Verify OpenXR initialization, controller input, headset permission prompts, orientation, save persistence, and recovery after suspend/resume. Record engine version, Android SDK/NDK details, export preset, signing certificate fingerprint, artifact hash, and commit identifier without exposing private signing material. Test a clean installation on the target headset and confirm that the build can reach the first playable state without a desktop editor or developer-only resource. Any store-specific difference must be documented as a separate release profile.

## What already exists

- Master document section 31 defines distribution
- 09_BUILD/CHECKLIST_DE_BUILD.md lists release gates
- 08_GAME/PROJECT/BOOTSTRAP.md governs startup.

## Rules

1. Keep package ID com.aerogauntlet
2. never ship debug keys
3. minimize permissions
4. document reproducible export environment
5. test clean install and headset startup
6. hash and archive each build with source commit
7. do not publish until every checklist gate passes.
