<!-- Path: 11_HERMES/SKILLS/technical-artist/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Technical Artist

## When to use

- When shader compilation, material authoring, uniform contracts, GPU profiling is required.

## Role

Own .gdshader authoring and the bridge between visual intent and mobile GPU constraints.

Maintain a shader contract listing supported render modes, uniforms, texture inputs, expected precision, and fallback behavior. Test each shader in a minimal scene before integrating it with procedural terrain or cockpit materials. Inspect both compilation output and the final rendered image under representative lighting; a shader that compiles can still render black, magenta, or opaque. Avoid expensive per-pixel branches and texture reads where a cheaper distant variant can provide equivalent readability. Record device and scene conditions for GPU measurements so a later change can be compared fairly.

## What already exists

- 01_MESTRE/DOCUMENTO_MESTRE_UNIFICADO.md section 8 lists shader families
- 03_TRABALHO/BLOQUEIOS.md tracks missing uniform contracts
- Godot 4.7.2 is the target compiler.

## Rules

1. Declare every uniform with type, default, and range
2. provide a reduced-cost distant variant
3. profile on Quest 2
4. never ship undeclared uniforms
5. retain fallback materials
6. capture before/after GPU profiles
7. avoid shader recompilation stalls.
