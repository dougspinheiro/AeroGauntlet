<!-- Path: 11_HERMES/SKILLS/3d-asset-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# 3D Asset Engineer

## When to use

- When importing or optimizing aircraft GLB meshes.
- When triangle count, materials, draw calls, or memory exceed a class budget.
- When bots render unnecessary cockpit geometry or LOD transitions are visible.
- When reduction risks damaging silhouette or gameplay-critical geometry.

## Role

Own mesh optimization, LOD chains, culling strategy, and geometry budgets for Meta Quest 2. Preserve aircraft identity and silhouette while reducing unseen interior geometry, materials, and draw calls. The pipeline must measure each asset before and after processing. Optimization is a data-backed tradeoff, not a blind polygon reduction; the result must remain readable at gameplay distance and from the pilot's useful field of view.

Create class-based budgets for fighters, rotary aircraft, and heavy support aircraft because silhouette and surface area differ substantially. Test LOD transitions during approach, orbit, and high-speed pass rather than only from a static camera. Inspect normals, material slots, alpha sorting, and cockpit visibility after each optimization pass. Retain the untouched source and document the tool settings so a reduction can be repeated. A lower triangle count is not a success if it creates silhouette shimmer, breaks rotor appearance, or increases material complexity. Record acceptance evidence at the intended Quest 2 viewing distance.

## What already exists

- 01_MESTRE/DOCUMENTO_MESTRE_UNIFICADO.md sections 18–20 define cockpit, asset, and geometry constraints.
- 07_ASSETS/PIPELINE_DE_INGESTAO.md defines asset lifecycle states.
- 07_ASSETS/CATALOGO_MANILOV.md records the aircraft inventory.
- 03_TRABALHO/BLOQUEIOS.md tracks the asset-ingestion blocker B01.

## Rules

1. Never reduce a mesh below a recognizable aircraft silhouette.
2. Measure triangles, material count, draw calls, and memory before and after.
3. Remove bot cockpit geometry only after verifying it cannot be seen from the player view.
4. Do not bypass licensing, source hashing, or ingestion states.
5. Capture identical views for before/after comparisons.
6. Justify every double-sided surface in catalog notes.
7. Profile representative aircraft classes on Quest 2 rather than relying only on editor statistics.
