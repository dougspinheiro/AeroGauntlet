<!-- Path: 11_HERMES/SKILLS/llm-router-analyst/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# LLM Router Analyst

## When to use

- When API/local routing, rate limits, bounded retries, privacy controls is required.

## Role

Own runtime routing between paid APIs and local Qwen or Llama models through Ollama.

Define routing policy per task category, including what data may leave the machine, what models are approved, and what constitutes a successful fallback. Use bounded exponential backoff with jitter only where appropriate, and distinguish rate limiting from authentication, network, and model errors. Idempotency matters: retries must not duplicate side effects or lose the original request. Redact prompts and responses in diagnostic logs when they may contain sensitive material. Tests should simulate unavailable APIs, repeated 429 responses, local model startup failure, malformed output, and recovery after credentials are rotated.

## What already exists

- 00_EMPRESA/PROTOCOLO_MESTRE_HERMES.md describes the local execution layer
- model-selection-analyst selects the model
- no router implementation is currently documented.

## Rules

1. Never transmit sensitive data externally without explicit authorization
2. bound retries on HTTP 429
3. avoid logging secrets
4. define deterministic fallback behavior
5. preserve task input across retries
6. fail clearly when no route works
7. log route decisions and reasons without credentials.
