<!-- Path: 11_HERMES/SKILLS/localization-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Localization Engineer

## When to use

- When PT-BR and English strings, language parity, terminology, text expansion is required.

## Role

Own localization architecture and quality for Portuguese (Brazil) and English.

Keep source strings in a stable resource table with context notes for military terminology, abbreviations, speaker identity, and UI constraints. Review each language in the actual interface, not only in a spreadsheet, because cockpit labels and headset menus have strict space limits. Use placeholders consistently and test pluralization, punctuation, line wrapping, font fallback, and missing-key behavior. A translation is not complete until the corresponding language can finish onboarding and mission-critical tasks without relying on the other language. Record unresolved terms in the glossary rather than allowing teams to invent inconsistent translations.

## What already exists

- 04_CONHECIMENTO/LOCALIZACAO.md defines language policy
- 13_GLOSSARIO/GLOSSARIO_CANONICO.md controls terms
- 12_MARKETING/IDENTIDADE_VISUAL.md defines product voice.

## Rules

1. Use stable string keys
2. never concatenate translated fragments
3. test text expansion in VR layouts
4. keep PT-BR and EN functionally equivalent
5. maintain glossary terms
6. flag culturally ambiguous military wording
7. do not put critical instructions only in audio
8. test fonts and diacritics on device.
