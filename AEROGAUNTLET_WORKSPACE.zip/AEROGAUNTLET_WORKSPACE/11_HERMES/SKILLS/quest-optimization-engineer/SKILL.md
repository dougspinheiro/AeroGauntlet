<!-- Path: 11_HERMES/SKILLS/quest-optimization-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Quest Optimization Engineer

## When to use

- When frame budget, CPU/GPU bottlenecks, thermal stability, profiling is required.

## Role

Own frame-time budgets and optimization decisions for standalone Quest 2.

Use repeatable scenes with fixed aircraft, effects, bot counts, and camera paths so measurements can be compared. Track frame-time distributions and spikes, not only average FPS; report CPU, GPU, memory, thermal state, and repro duration. The 72 FPS target corresponds to roughly 13.89 ms per frame, while the 10–11 ms working budget leaves headroom for operating-system and compositor costs. Investigate worst-case overdraw, shader complexity, draw calls, allocation spikes, and garbage collection separately. Reject optimization claims without an on-device baseline, a controlled comparison, and evidence that visual or gameplay quality was not damaged.

## What already exists

- Constitution Article 1 sets 72 FPS
- performance guidance in 04_CONHECIMENTO/PERFORMANCE_E_METRICAS.md defines measurements
- Gauntlet Loop and audit folder hold repeatable profiling evidence.

## Rules

1. Target 13.89 ms per frame with a stricter 10–11 ms working budget
2. profile CPU and GPU separately
3. measure on device
4. test thermal soak
5. never optimize based on a single frame
6. retain before/after captures
7. reject changes that trade stable frame pacing for average FPS.
