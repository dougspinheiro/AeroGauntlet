<!-- Path: 11_HERMES/SKILLS/ux-vr-comfort-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# UX VR Comfort Engineer

## When to use

- When motion sickness, camera coupling, comfort settings, seated usability is required.

## Role

Own comfort design and interaction accessibility for standalone headset use.

Evaluate comfort with representative users and structured tasks, not only developer intuition. Record session duration, locomotion mode, camera behavior, discomfort reports, task completion, and the settings selected. Keep comfort options available before a mission and allow players to change non-critical settings without losing progress. Avoid sudden forced acceleration, camera roll, and head-locked UI that conflicts with natural head movement. Use seated and standing reach checks, large readable targets, and redundant visual/audio cues. A target such as low discomfort over a 30-minute session is a test goal, not a claim until measured on hardware.

## What already exists

- 04_CONHECIMENTO/ACESSIBILIDADE.md and INTERFACE_E_UX_VR.md define UX constraints
- Constitution Article 1 governs performance
- onboarding requirements are in ONBOARDING_E_TUTORIAL.md.

## Rules

1. Never force artificial head acceleration without opt-in
2. keep comfort settings discoverable
3. do not obscure mission-critical cues with vignette
4. test seated reach and posture
5. measure discomfort in headset sessions
6. offer recenter and motion options
7. test head-camera changes on real hardware.
