<!-- Path: 11_HERMES/SKILLS/player-research-analyst/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Player Research Analyst

## When to use

- When public reviews, repeated pain points, player hypotheses, qualitative coding is required.

## Role

Analyze player feedback as a dated, traceable evidence set and convert recurring themes into testable hypotheses.

Use a coding guide with definitions and examples for each theme so separate reviewers classify comments consistently. Preserve enough surrounding context to avoid reversing a reviewer's meaning, while quoting only what is necessary. Record the collection method and date range, and avoid comparing raw counts from platforms with very different review volumes. Prioritize reports that describe blocked play, discomfort, confusion, or repeatable defects, then design a neutral task to test the hypothesis. Do not treat a positive or negative review as representative of all players without a defensible sampling method.

## What already exists

- 12_MARKETING/PESQUISA_DE_JOGADORES.md defines recording categories
- 04_CONHECIMENTO/DESIGN_DE_JOGO/ESTUDO_DE_REFERENCIAS_VR_AEREO.md stores reference research
- Constitution Article 10 requires market intelligence.

## Rules

1. Preserve source links and dates
2. never fabricate quotations
3. distinguish anecdote from pattern
4. record sample size and selection bias
5. use neutral coding
6. do not infer demographics
7. validate findings with in-house tests
8. treat negative feedback as evidence, not messaging to suppress.
