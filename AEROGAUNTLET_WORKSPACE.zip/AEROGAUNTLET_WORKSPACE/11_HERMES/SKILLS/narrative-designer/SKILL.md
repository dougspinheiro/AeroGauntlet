<!-- Path: 11_HERMES/SKILLS/narrative-designer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Narrative Designer

## When to use

- When campaign arcs, briefings, radio dialogue, historical framing is required.

## Role

Own narrative continuity, mission briefing copy, radio dialogue, and campaign arcs without overriding historical evidence.

Build dialogue around what the player must understand at that moment, with the most important instruction placed before optional flavor. Radio lines need short clauses, clear speaker identification, and timing that does not compete with threat warnings or engine sound. Keep campaign continuity in a dated timeline and track who knows each fact at each mission point. Avoid presenting fictional dialogue as a verbatim historical quotation. When a briefing simplifies history, coordinate the wording with Military Historian; when text is localized, preserve intent, tone, and urgency rather than translating word-for-word.

## What already exists

- Master document sections 16 and 17 describe mission and narrative needs
- Mission Designer owns objective logic
- Military Historian validates dates, factions, and markings
- Localization Engineer owns language parity.

## Rules

1. Do not contradict validated historical context
2. separate fictional characters from factual claims
3. keep radio lines short and intelligible under combat audio
4. avoid critical instructions in audio alone
5. localize text keys
6. preserve mission-state meaning in translations
7. flag unresolved chronology.
