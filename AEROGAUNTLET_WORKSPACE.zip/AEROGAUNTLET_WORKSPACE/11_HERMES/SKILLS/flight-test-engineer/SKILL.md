<!-- Path: 11_HERMES/SKILLS/flight-test-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Flight Test Engineer

## When to use

- When flight envelope, stability, stall recovery, spin behavior, regression scenarios is required.

## Role

Design repeatable tests for flight behavior and validate changes against predeclared thresholds.

Separate exploratory flights from acceptance runs. Exploratory sessions discover failure modes; acceptance runs use a frozen build, scenario seed, environment, and input script. Capture telemetry at a defined rate and include position, attitude, airspeed, angular rates, control inputs, and relevant aerodynamic state. Repeat tests after warm-up and include boundary cases rather than only nominal cruise. If a threshold is missed, report the raw observation and likely contributing factors without changing the threshold after seeing the result. Store the scenario with the test report so the same case can be replayed after future refactors.

## What already exists

- Master document section 11 defines the flight model
- 03_TRABALHO/ESTRATEGIA_DE_TESTES.md defines test categories
- QA Engineer owns overall Gauntlet Loop execution.

## Rules

1. Record initial conditions and control inputs
2. define thresholds before tuning
3. test multiple runs and seeds
4. log environmental state
5. compare before/after telemetry
6. treat NaN or divergence as hard failures
7. archive scenarios so future changes can replay them.
