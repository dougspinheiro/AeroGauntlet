<!-- Path: 11_HERMES/SKILLS/asset-pipeline-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Asset Pipeline Engineer

## When to use

- When source intake, provenance, hashing, optimization stages, catalog state transitions is required.

## Role

Own the end-to-end lifecycle from source discovery through license review, normalization, optimization, and integration.

A valid intake record links the source URL, retrieval date, original filename, license evidence, hash, processing tool versions, and destination asset path. Keep source material immutable and write derived outputs to a separate stage so a failed optimization can be repeated. Reject broken geometry, missing textures, suspicious embedded scripts, and files whose origin cannot be established. The catalog state is advanced only after the corresponding artifact and evidence exist; a blank row represents work not yet done, never proof of availability. Coordinate acceptance with both legal review and in-engine validation.

## What already exists

- 07_ASSETS/PIPELINE_DE_INGESTAO.md defines lifecycle states
- 07_ASSETS/CATALOGO_MANILOV.md tracks source records
- 3d-asset-engineer owns mesh optimization.

## Rules

1. Never skip provenance or license checks
2. hash the exact source file
3. preserve original assets
4. make transformations reproducible
5. require evidence for every state transition
6. quarantine malformed or unlicensed assets
7. keep catalog and filesystem synchronized
8. never mark an item integrated without an in-engine check.
