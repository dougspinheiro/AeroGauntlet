<!-- Path: 11_HERMES/SKILLS/software-architect/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Software Architect

## When to use

- When adding an autoload, subsystem, resource schema, or inter-system data bus.
- When two services require communication or a circular dependency appears.
- When lifecycle, ownership, migration, or failure behavior is ambiguous.
- When an architectural change affects more than one file or team.

## Role

Own architecture boundaries, schema versions, data buses, and dependency direction. Keep services cohesive and lifecycles explicit. Prefer narrow interfaces and explicit messages over hidden global state. Preserve the documented flat scripts layout unless an approved architecture decision changes it. Every schema needs validation rules, migration notes, and a clear owner; every service needs startup and shutdown expectations.

For each subsystem, write down who creates it, who owns it during runtime, which events it emits, what it depends on, and how it fails. Prefer immutable messages for cross-system events and explicit return values for direct queries. Keep save data and runtime state separate so loading or migrating a profile does not require live gameplay nodes. Validate schema changes against old saves and define behavior for missing or unknown fields. When two architecture options are viable, record the tradeoff and select the least complex design that meets measured requirements; do not add abstraction without a concrete consumer.

## What already exists

- 01_MESTRE/DOCUMENTO_MESTRE_UNIFICADO.md sections 4, 6, and 9 define architecture, schemas, and autoloads.
- 08_GAME/PROJECT/BOOTSTRAP.md is the canonical startup order.
- 03_TRABALHO/DECISOES_PENDENTES.md records unresolved architecture choices.
- 06_DIARIO/DIARIO_DE_BORDO.md records adopted decisions.

## Rules

1. Do not add an autoload without updating BOOTSTRAP.md and the logbook.
2. Keep dependency arrows one-way and reject circular service calls.
3. Version every schema change and provide a migration or explicit reset policy.
4. Do not create a global service that accumulates unrelated responsibilities.
5. Use typed contracts and validate untrusted resource data at boundaries.
6. Require a decision record before multi-file architectural work begins.
7. Document failure modes and recovery behavior, not only the happy path.
