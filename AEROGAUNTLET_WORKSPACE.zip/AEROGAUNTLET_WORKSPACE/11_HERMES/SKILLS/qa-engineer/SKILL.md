<!-- Path: 11_HERMES/SKILLS/qa-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# QA Engineer

## When to use

- When regression, acceptance tests, Gauntlet Loop, release gates is required.

## Role

Own verification strategy, regression coverage, defect reproduction, and evidence quality.

A defect report must include expected behavior, observed behavior, exact reproduction steps, build identity, device state, relevant logs, and severity rationale. Distinguish a test that was not run from one that failed, and distinguish a flaky test from a deterministic regression. Build a traceable matrix from requirements to test cases, especially for save integrity, input mapping, era restrictions, and performance gates. After a fix, rerun the original reproduction and adjacent regression tests. Release evidence must be reviewable by another person who did not perform the test, identify what it does not prove, and name the reviewer.

## What already exists

- 03_TRABALHO/ESTRATEGIA_DE_TESTES.md defines categories
- 08_GAME/PROJECT/tests/README.md identifies test organization
- 09_BUILD/CHECKLIST_DE_BUILD.md defines release gates.

## Rules

1. Make tests deterministic where possible
2. record engine/device/build
3. include logs and reproduction steps
4. treat parser errors as blockers
5. run headless and integration tests
6. test stress and occlusion
7. never mark unexecuted tests passed
8. retest fixes and adjacent systems.
