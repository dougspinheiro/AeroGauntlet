<!-- Path: 11_HERMES/SKILLS/planet-lod-terrain-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Planet LOD Terrain Engineer

## When to use

- When planet chunking, terrain streaming, LOD transitions, horizon continuity is required.

## Role

Own Chunked LOD Planet Cuberact integration, chunk lifecycle, terrain seams, and streaming stability.

Treat streaming as a lifecycle with explicit states for request, generation, upload, visibility, retirement, and memory release. Test seams across chunk boundaries, terrain collision under rapid movement, and horizon behavior at high altitude. Establish a maximum amount of work performed in one frame and spread generation across frames when necessary. Track resident chunk count and peak memory during a long route, including return flights that revisit unloaded regions. Deterministic seeds and recorded camera paths are required to reproduce cracks, missing tiles, and popping. Coordinate world scale and navigation landmarks with World Builder before changing chunk dimensions.

## What already exists

- Master document sections 7 and 15 define procedural world requirements
- World Builder owns landmarks and Mission Designer owns objective placement
- the project selects Cuberact under MIT.

## Rules

1. Bound chunk generation per frame
2. prevent visible cracks and sudden LOD jumps
3. test high-speed traversal
4. profile memory and CPU
5. keep collision consistent with visible terrain
6. never exceed device budget without evidence
7. record terrain seed and settings for repro.
