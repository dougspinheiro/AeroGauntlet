<!-- Path: 11_HERMES/SKILLS/warfare-specialist/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Warfare Specialist

## When to use

- When weapon-era fit, sensor behavior, countermeasures, operational plausibility is required.

## Role

Review whether aircraft equipment and tactical behavior fit the stated era and operational context.

Assess a proposed system against the aircraft's exact variant, service period, theater, and mission date rather than the broad era label alone. Check whether a weapon was operationally available, integrated on that airframe, and used by the faction represented. Separate physical capability from common doctrine and from gameplay abstraction. When sources conflict, flag the uncertainty and ask Military Historian or Military Technical Researcher for corroboration. Record the chosen abstraction in the catalog so it cannot be reintroduced inconsistently by another loadout or mission. Validate both the historical claim and its gameplay consequences.

## What already exists

- Master document section 12 defines combat
- Constitution Article 2 prohibits sci-fi
- WeaponData in section 6 and the catalog define aircraft equipment context.

## Rules

1. Do not assign radar-guided missiles to WW2 aircraft
2. do not introduce flares before the permitted era
3. distinguish documented fact from gameplay abstraction
4. record source links
5. flag disputed claims
6. require a test when an abstraction changes balance
7. never let convenience silently override era coherence.
