<!-- Path: 11_HERMES/SKILLS/ai-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# AI Engineer

## When to use

- When enemy aircraft fail to engage, evade, return, or reacquire targets correctly.
- When state transitions oscillate or bots react to information they could not observe.
- When increasing bot counts threatens CPU or frame-time budgets.
- When difficulty needs tuning without impossible accuracy or hidden player knowledge.

## Role

Own the enemy-aircraft decision state machine and perception budget. States include PATROL, CHASE, ATTACK, EVADE, RETURN, and INCAPACITATED. Each transition must have a visible condition, timeout or debounce where appropriate, and a safe fallback. Perception uses bounded range, line of sight, and noisy observations. Difficulty adjusts tolerances and decision quality, not access to impossible information. Stagger expensive decisions across frames.

Define the observable inputs and output actions for each AI state. Use hysteresis around range and angle thresholds so a target hovering near a boundary does not cause rapid state changes. Budget sensing, path planning, and tactical selection independently, and distribute updates across agents when the workload grows. Include disengagement and recovery logic so bots do not pursue forever or enter impossible flight states. For each difficulty level, specify which tolerances change and which physical limits remain fixed. Save a trace containing state, target, decision cause, and transition time for each repeatable test encounter.

## What already exists

- 01_MESTRE/DOCUMENTO_MESTRE_UNIFICADO.md section 13 defines AI behavior.
- EnemyData in master document section 6 is the behavior schema.
- 08_GAME/PROJECT/BOOTSTRAP.md defines runtime service initialization.
- 03_TRABALHO/ESTRATEGIA_DE_TESTES.md supplies regression scenarios.

## Rules

1. Never permit a state to churn every frame without a debounce or progress condition.
2. Bots may act only on observations available to their simulated sensors.
3. Do not instantiate or render bot cockpit or instrument trees.
4. Bound perception range, target count, and expensive decision frequency.
5. Log state transitions and decision causes in a debug trace.
6. Validate 1v1, 4v4, and 8v8 with fixed seeds and initial conditions.
7. Measure CPU time and frame time on the target device before raising bot limits.
