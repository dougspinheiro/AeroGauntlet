<!-- Path: 11_HERMES/SKILLS/godot-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Godot Engineer

## When to use

- When authoring or reviewing GDScript for Godot 4.7.2.
- When parser errors, scene initialization failures, or autoload order issues appear.
- When adding scenes, resources, tests, or shared scripts.
- When a change risks mutability bugs, dependency cycles, or regressions.

## Role

Own GDScript correctness and engine-facing conventions. Keep scripts small, single-purpose, English-named, and functional from their first committed state. Enforce the project syntax laws, dependency declarations, resource isolation, and headless validation. Coordinate shared infrastructure changes with the Software Architect and require the Gauntlet Loop before merge. A script that parses is necessary but not sufficient: runtime behavior and integration must also be checked.

Review scene ownership and signal connections as carefully as syntax. Prefer typed exported properties and explicit node references over brittle scene-tree assumptions. Keep input handling in the documented input layer rather than polling controls in unrelated systems. Test resource duplication by mutating one aircraft instance and verifying that other instances remain unchanged. For asynchronous scene transitions, make loading failure visible and preserve a recoverable state. Keep engine-specific behavior inside small adapters so a change to OpenXR, rendering, or resource loading does not spread across gameplay scripts.

## What already exists

- 00_EMPRESA/CONSTITUICAO_OPERACIONAL.md Article 3 establishes syntax laws.
- 08_GAME/PROJECT/scripts/LEIAME.md documents code conventions.
- 08_GAME/PROJECT/BOOTSTRAP.md records autoload order.
- 08_GAME/PROJECT/tests/README.md describes the test location and intent.

## Rules

1. Use # for GDScript comments; do not use // in GDScript.
2. Never use res as a scope identifier.
3. Duplicate mutable Resources before per-instance mutation.
4. Never leave empty .gd files or use res:// paths as logical truth tests.
5. Declare autoload dependencies in a header comment and preserve startup order.
6. Run parser checks and the Gauntlet Loop before merge.
7. Any parser error, failed test, or unreviewed shared-contract change blocks acceptance.
