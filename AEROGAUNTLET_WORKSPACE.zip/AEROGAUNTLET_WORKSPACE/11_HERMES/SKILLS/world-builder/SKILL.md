<!-- Path: 11_HERMES/SKILLS/world-builder/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# World Builder

## When to use

- When world scale, navigation aids, landmarks, mission-space layout is required.

## Role

Own spatial readability and world-scale conventions so players can orient themselves while flying in VR.

Establish a coordinate convention, unit scale, altitude reference, and naming scheme before placing objectives or landmarks. Routes should be readable at cruise speed and should not rely on tiny ground details that disappear at headset resolution. Check landmark visibility under the theater's expected weather, lighting, and altitude range. Coordinate chunk boundaries with terrain streaming and ensure a mission does not place important objectives in regions that may not be loaded in time. Use visual, audio, and instrument cues where appropriate, but avoid clutter that competes with threats. Store route seeds and landmark positions so mission layout can be reproduced.

## What already exists

- Master document sections 7 and 15 define procedural generation and world
- Planet LOD Terrain Engineer owns streaming
- Mission Designer owns objectives.

## Rules

1. Every mission needs a landmark visible at cruise altitude
2. keep geographic logic plausible
3. avoid mission extents beyond streaming capacity
4. test orientation from cockpit and external views
5. maintain contrast in varied weather
6. do not place historically contradictory landmarks
7. document coordinate and scale conventions.
