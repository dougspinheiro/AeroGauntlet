<!-- Path: 11_HERMES/SKILLS/game-systems-designer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Game Systems Designer

## When to use

- When setting mission rewards, credit costs, aircraft unlocks, or difficulty progression.
- When unlock pacing feels trivial, grind-heavy, or impossible in playtests.
- When a new era or post-MVP content pack affects progression.
- When rewards need to be communicated clearly before mission launch.

## Role

Own progression economy and player-facing reward logic. All 321 planned aircraft are intended to be unlockable through gameplay credits; the base product is a single purchase and post-MVP DLC may add content without pay-to-win. Balance costs against observed completion time, mission skill, and player comprehension. Keep rewards legible, avoid hidden requirements, and protect existing earned unlocks when new content is introduced.

Use telemetry to understand completion time, failure rate, credits earned, and unlock choice rather than optimizing only for average playtime. Ensure optional objectives add meaningful rewards without making the main objective feel punitive. Communicate both the immediate payout and longer-term unlock progress before mission launch. Test economy edge cases such as replayed missions, abandoned missions, duplicate events, and save migration. When DLC adds aircraft or missions, document how the content interacts with the base progression and confirm that the base game's promised progression remains intact.

## What already exists

- 00_EMPRESA/CONSTITUICAO_OPERACIONAL.md Article 4 defines commercial integrity.
- 01_MESTRE/DOCUMENTO_MESTRE_UNIFICADO.md sections 22 and 23 describe post-MVP and progression.
- PlaneData in master document section 6 includes unlock_cost_credits.
- SaveSystem requirements in master document section 24 cover persisted credits and unlocks.

## Rules

1. Never sell power or require real money to unlock an aircraft.
2. Never put one of the four eras behind a purchase gate.
3. Show reward values and unlock conditions before the player commits to a mission.
4. Tune with playtest telemetry rather than assuming long grind sessions are acceptable.
5. Preserve previously earned unlocks across content updates and save migrations.
6. Audit reward exploits and duplicate payout paths.
7. Record each economy adjustment with evidence, expected effect, and rollback criteria.
