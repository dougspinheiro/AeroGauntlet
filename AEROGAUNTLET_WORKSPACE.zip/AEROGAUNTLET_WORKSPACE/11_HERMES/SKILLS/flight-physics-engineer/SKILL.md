<!-- Path: 11_HERMES/SKILLS/flight-physics-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Flight Physics Engineer

## When to use

- When implementing lift, drag, thrust, gravity, wind, stall, or control response.
- When tuning aircraft coefficients or diagnosing oscillation, spin, hover instability, or inverted controls.
- When separating fixed-wing and rotary-wing dynamics or translating reference data into gameplay.
- When a flight change needs measurable envelope and stability criteria.

## Role

Own the aerodynamic model and the flight integration contract. Fixed-wing behavior includes lift versus airspeed and angle of attack, drag, thrust, gravity, control authority, and stall. Rotary-wing behavior adds collective, cyclic, anti-torque, torque compensation, translational lift, and simplified ground effect. Keep SI units and explain every coefficient with a source or calibration note. Supply telemetry that makes tuning reproducible rather than subjective.

Separate model error from input error by replaying fixed control sequences and then repeating the test with neutral controls. Test the envelope at low speed, cruise, high speed, high angle of attack, and boundary conditions appropriate to each aircraft class. Use explicit clamps only when they represent a documented physical or gameplay limit; clamps must not conceal numerical divergence. For rotary aircraft, verify hover stability, pedal response, collective authority, and translational lift separately. Any coefficient change should identify the aircraft variants affected and include a rollback path if regression results exceed the acceptance threshold.

## What already exists

- 01_MESTRE/DOCUMENTO_MESTRE_UNIFICADO.md section 11 defines the force model F_total = thrust + drag + lift + gravity + wind.
- 08_GAME/PROJECT/BOOTSTRAP.md defines service startup order.
- 08_GAME/PROJECT/INPUT_MAP.md maps pitch, roll, yaw, and throttle actions.
- PlaneData in the master document section 6 is the aircraft input schema.
- 03_TRABALHO/BLOQUEIOS.md tracks the rotary-physics blocker B02.

## Rules

1. Apply each physical force exactly once and assign one owner to each integration step.
2. Dispatch fixed-wing and rotary-wing behavior explicitly using PlaneData.superclass.
3. Use SI units internally and document every conversion at data boundaries.
4. Reject NaN, infinity, divergence at rest, and unbounded angular velocity.
5. Record initial conditions and before/after telemetry for coefficient changes.
6. Do not tune from feel alone; define a measurable target and repeatable scenario first.
7. Keep aerodynamic equations separate from input mapping and presentation effects.
