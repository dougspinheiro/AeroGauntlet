<!-- Path: 11_HERMES/SKILLS/mission-designer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Mission Designer

## When to use

- When objectives, briefing flow, mission pacing, era-specific scenarios is required.

## Role

Own mission structure, objectives, success/failure conditions, and pacing across the four eras.

Write a mission contract before building its scene: player role, theater, date, objective, success condition, failure condition, expected duration, available aircraft, and expected enemy pressure. Objectives should be understandable from briefing and in-flight cues, with no critical step depending on an easily missed audio line. Create a short route that exposes the player to the intended mechanic, then a later challenge that tests transfer. Record spawn conditions and completion criteria so QA can replay the mission deterministically. When scope is reduced, preserve the mission's core learning or dramatic purpose rather than adding unrelated objectives.

## What already exists

- Master document section 16 defines mission requirements
- MissionData is specified in section 6
- World Builder owns spatial landmarks and Narrative Designer owns story and radio text.

## Rules

1. Every mission needs a clear objective and completion test
2. use era-valid aircraft and equipment
3. include a cruise-altitude navigation landmark
4. define fail states
5. budget enemy count
6. ensure objective markers remain legible in VR
7. test first-time comprehension.
