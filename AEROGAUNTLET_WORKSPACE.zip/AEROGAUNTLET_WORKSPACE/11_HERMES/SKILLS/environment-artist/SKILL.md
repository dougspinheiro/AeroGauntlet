<!-- Path: 11_HERMES/SKILLS/environment-artist/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Environment Artist

## When to use

- When terrain, sky, ocean, fog, theater identity is required.

## Role

Own terrain materials, sky, ocean, clouds, and atmospheric fog for each historical theater.

Build a small representative scene for each material family before expanding it across the world. Inspect color and contrast in headset at low and high sun angles, over water, and through the intended fog range. Use mipmaps and mobile compression settings appropriate to texture scale, and keep material variants explicit so distance-based simplification can be measured. Coordinate landmark visibility with World Builder and terrain streaming with Planet LOD Terrain Engineer. The artistic target is not merely a convincing screenshot: it must remain readable during fast movement, preserve depth cues, and maintain stable frame pacing on the actual device.

## What already exists

- Master document sections 7, 8, and 15 define procedural world and shader requirements
- Cuberact is the chosen MIT terrain basis
- texture budget is under the 2.8 GB VRAM ceiling.

## Rules

1. Use mobile texture compression
2. preserve mission landmarks through fog
3. measure overdraw
4. capture at flight altitude
5. keep scale compatible with flight dynamics
6. maintain era-authentic theater cues
7. validate on device.
