<!-- Path: 11_HERMES/SKILLS/combat-engineer/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Combat Engineer

## When to use

- When adding or changing guns, cannons, rockets, missiles, damage, or countermeasures.
- When weapon availability, rate of fire, dispersion, ammunition, or damage is duplicated in code.
- When lock, hit, miss, flare, chaff, or radar-warning feedback needs implementation.
- When an aircraft loadout is inconsistent with its era or source record.

## Role

Own runtime weapon behavior and the data-driven combat contract. WW1 weapons use synchronized machine guns and linear ballistic approximation; WW2 emphasizes cannon ballistics and unguided rockets; Cold War supports early rear-aspect infrared missiles and basic warning systems; Modern supports BVR radar missiles, chaff, flares, and threat display. Weapon definitions belong in WeaponData resources so aircraft loadouts, balance, and tests consume one source of truth.

Treat weapon simulation as a chain of explicit stages: trigger validation, ammunition consumption, projectile or seeker creation, guidance, collision, damage application, and player feedback. Each stage needs a defined owner and a testable failure mode. Use swept collision or another justified method for fast projectiles to reduce missed hits caused by tunneling. Keep weapon effects readable without obscuring aircraft orientation or inducing excessive overdraw. Validate reload, cooldown, out-of-ammunition, target-loss, and countermeasure cases in addition to successful hits. The catalog and WeaponData must agree on allowed loadouts before a mission can be accepted.

## What already exists

- 01_MESTRE/DOCUMENTO_MESTRE_UNIFICADO.md sections 6 and 12 define WeaponData and combat requirements.
- 07_ASSETS/CATALOGO_MANILOV.md is the planned aircraft/loadout source inventory.
- 03_TRABALHO/ESTRATEGIA_DE_TESTES.md defines repeatable validation categories.
- 08_GAME/PROJECT/scripts/LEIAME.md establishes script conventions.

## Rules

1. Never equip an aircraft with weapons unavailable in its documented era.
2. Read ammunition, cadence, dispersion, damage, and guidance parameters from WeaponData.
3. Give every missile guidance mode an explicit update loop and observable failure conditions.
4. Model flare and chaff effectiveness probabilistically and document the curve.
5. Keep projectile lifetime, collision, and damage application deterministic for tests.
6. Build a reproducible scenario for every weapon change before calling it validated.
7. Separate visual hit feedback from authoritative damage resolution.
