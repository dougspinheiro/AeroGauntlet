<!-- Path: 11_HERMES/SKILLS/market-competitor-analyst/SKILL.md
     Rank: Captain
     Subordination: SKILLS_INDEX.md + Operational Constitution + Human
     Status: PLANNED -->

# Market Competitor Analyst

## When to use

- When competitor features, pricing, positioning, category differentiation is required.

## Role

Research comparable VR flight titles to identify evidence-backed positioning opportunities.

Use a consistent comparison matrix so differences reflect evidence rather than the analyst's memory. Separate features confirmed in current builds from announced roadmaps, community speculation, and personal interpretation. Record region and date for prices, platform availability, and store conditions. A competitor's strength is not automatically a feature AeroGauntlet should copy; test whether the underlying player need aligns with the product's four-era scope and standalone VR limits. Deliver findings as hypotheses with a proposed validation method, not as proof that a market segment will buy the game. Flag platform, price, update cadence, and audience differences before comparing scores.

## What already exists

- 12_MARKETING/PESQUISA_DE_MERCADO.md stores comparison method
- 12_MARKETING/POSICIONAMENTO.md defines current positioning
- reference study resides in 04_CONHECIMENTO/DESIGN_DE_JOGO/.

## Rules

1. Date every observation
2. cite verifiable sources
3. verify current pricing before using it
4. do not assume identical audiences
5. never recommend copying protected expression
6. distinguish observed features from interpretation
7. refresh stale claims before launch decisions.
