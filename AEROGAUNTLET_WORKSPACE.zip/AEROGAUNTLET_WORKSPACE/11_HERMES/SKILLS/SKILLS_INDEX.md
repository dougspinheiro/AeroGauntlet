<!-- Path: 11_HERMES/SKILLS/SKILLS_INDEX.md
     Rank: Colonel
     Subordination: Operational Constitution + Human
     Status: FOUNDATIONAL -->

# Skills Index

This index is the canonical registry of 31 specialist skills. Invoke a skill by its exact directory name. Each skill owns the scope stated below and must follow the Operational Constitution.

- `hermes-core` — `11_HERMES/SKILLS/hermes-core/SKILL.md` — Coordinates execution as CEO, arbitrates cross-discipline conflicts, protects workspace integrity, and reports to the Human.
- `flight-physics-engineer` — `11_HERMES/SKILLS/flight-physics-engineer/SKILL.md` — Owns fixed-wing and rotary-wing flight dynamics using F_total = thrust + drag + lift + gravity + wind.
- `combat-engineer` — `11_HERMES/SKILLS/combat-engineer/SKILL.md` — Implements era-appropriate weapons: WW1 machine guns, WW2 cannons, Cold War IR missiles, and Modern BVR radar missiles.
- `ai-engineer` — `11_HERMES/SKILLS/ai-engineer/SKILL.md` — Builds enemy swarm behavior with PATROL, CHASE, ATTACK, EVADE, and RETURN states.
- `godot-engineer` — `11_HERMES/SKILLS/godot-engineer/SKILL.md` — Owns Godot 4.7.2 and GDScript implementation quality.
- `software-architect` — `11_HERMES/SKILLS/software-architect/SKILL.md` — Defines data buses, autoload boundaries, schemas, and dependency direction.
- `game-systems-designer` — `11_HERMES/SKILLS/game-systems-designer/SKILL.md` — Designs progression, gameplay credits, and the unlock economy for 321 aircraft.
- `3d-asset-engineer` — `11_HERMES/SKILLS/3d-asset-engineer/SKILL.md` — Optimizes aircraft meshes, LOD chains, backface culling, and bot cockpit removal.
- `technical-artist` — `11_HERMES/SKILLS/technical-artist/SKILL.md` — Authors .gdshader materials and bridges art requirements with runtime constraints.
- `environment-artist` — `11_HERMES/SKILLS/environment-artist/SKILL.md` — Creates terrain materials, sky, ocean, and atmospheric fog appropriate to each era and theater.
- `planet-lod-terrain-engineer` — `11_HERMES/SKILLS/planet-lod-terrain-engineer/SKILL.md` — Integrates Chunked LOD Planet Cuberact under the MIT license.
- `mission-designer` — `11_HERMES/SKILLS/mission-designer/SKILL.md` — Structures missions by era with objectives, briefings, rewards, and failure conditions.
- `narrative-designer` — `11_HERMES/SKILLS/narrative-designer/SKILL.md` — Creates campaign arcs, radio dialogue, briefing copy, and mission context.
- `quest-optimization-engineer` — `11_HERMES/SKILLS/quest-optimization-engineer/SKILL.md` — Enforces frame budgets and may veto changes that threaten Quest 2 performance.
- `qa-engineer` — `11_HERMES/SKILLS/qa-engineer/SKILL.md` — Runs the headless Gauntlet Loop, automation_qa.gd, crash-log analysis, and regression tracking.
- `android-build-engineer` — `11_HERMES/SKILLS/android-build-engineer/SKILL.md` — Owns signed APK generation, OpenXR configuration, package identity, and store submission readiness.
- `warfare-specialist` — `11_HERMES/SKILLS/warfare-specialist/SKILL.md` — Checks era-consistent weapons, ballistics, radar, countermeasures, and operational plausibility.
- `military-historian` — `11_HERMES/SKILLS/military-historian/SKILL.md` — Validates aircraft, factions, theaters, dates, markings, and era coherence.
- `aviation-engineer` — `11_HERMES/SKILLS/aviation-engineer/SKILL.md` — Supplies real-aircraft performance references including wing loading, thrust-to-weight, stall speed, and G limits.
- `flight-test-engineer` — `11_HERMES/SKILLS/flight-test-engineer/SKILL.md` — Designs flight-envelope tests for stability, control response, stall recovery, and spin behavior.
- `world-builder` — `11_HERMES/SKILLS/world-builder/SKILL.md` — Defines world scale, landmarks, navigation aids, and spatial orientation.
- `military-technical-researcher` — `11_HERMES/SKILLS/military-technical-researcher/SKILL.md` — Researches aircraft systems, sensors, avionics, and operational constraints.
- `ux-vr-comfort-engineer` — `11_HERMES/SKILLS/ux-vr-comfort-engineer/SKILL.md` — Owns VR comfort, motion-sickness mitigation, vignette, snap turn, recenter, and seated mode.
- `player-research-analyst` — `11_HERMES/SKILLS/player-research-analyst/SKILL.md` — Analyzes public player reviews to identify recurring patterns rather than isolated anecdotes.
- `market-competitor-analyst` — `11_HERMES/SKILLS/market-competitor-analyst/SKILL.md` — Studies VTOL VR, Iron Wings, Flycatcher, Warplanes, Ultrawings 2, and Dawn of Jets.
- `skill-forge` — `11_HERMES/SKILLS/skill-forge/SKILL.md` — Creates, audits, and maintains specialist skill definitions.
- `model-selection-analyst` — `11_HERMES/SKILLS/model-selection-analyst/SKILL.md` — Selects suitable language models for tasks based on quality, latency, cost, and privacy.
- `llm-router-analyst` — `11_HERMES/SKILLS/llm-router-analyst/SKILL.md` — Routes tasks between paid APIs and local Qwen or Llama models through Ollama.
- `air-combat-specialist` — `11_HERMES/SKILLS/air-combat-specialist/SKILL.md` — Applies air-combat tactics including energy management, BFM, missile evasion, and formation flying.
- `asset-pipeline-engineer` — `11_HERMES/SKILLS/asset-pipeline-engineer/SKILL.md` — Owns PIPELINE_DE_INGESTAO.md and the lifecycle of all 321 manilov.ap assets.
- `localization-engineer` — `11_HERMES/SKILLS/localization-engineer/SKILL.md` — Owns LOCALIZACAO.md and the PT-BR plus English localization pipeline.
