<!-- Path: 13_GLOSSARIO/GLOSSARIO_CANONICO.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Canonical Glossary

| Canonical term | Definition | Usage rule |
|---|---|---|
| Human | Supreme authority over product scope, identity, asset-source choice, and constitutional targets. | Do not use as a synonym for CEO. |
| CEO | Executive authority for engineering, architecture, prioritization, integration, and execution. | Reports to Human; does not unilaterally change protected scope. |
| Operational Constitution | Supreme project law governing scope, performance, syntax, commercial integrity, and validation. | All project documents are subordinate to it. |
| Real Validation Gate | Evidence-based acceptance threshold for implementation and release claims. | Untested work is not validated. |
| Day Zero | Baseline state in which assumptions and artifacts are unvalidated until evidence passes. | Do not infer implementation from planning documents. |
| Gauntlet Loop | Automated and measured quality process combining syntax checks, headless tests, stress tests, and profiling. | Headless checks do not replace headset tests. |
| AeroGauntlet | The VR aerial combat simulator defined by this workspace. | Scope is limited to WW1, WW2, Cold War, and Modern eras. |
| Era | One of WW1, WW2, Cold War, or Modern. | No additional era is authorized. |
| Aircraft catalog | The planned set of 321 aircraft source IDs from manilov.ap. | An entry is not distributable until license and technical gates pass. |
| Validated | A status supported by reproducible evidence for a stated environment. | Never use as an aspiration or assumption. |
| Planned | Specified but not implemented or validated. | Use for future work and untested design. |
| Active | Work is in progress with a known owner. | Include acceptance criteria and next action. |
| Gameplay credits | In-game currency earned through play and used to unlock content. | Must not be bypassed by paid competitive advantages. |

Avoid ambiguous synonyms for these terms in technical records. If a concept does not match a canonical definition, define it explicitly rather than stretching an existing term.
