<!-- Path: 13_GLOSSARIO/LEIAME.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Canonical Glossary

This directory defines authoritative terms used throughout the workspace. Use glossary terms consistently in requirements, status reports, tests, and handoffs. If a new term is needed, propose a single definition and identify affected documents before adopting it.
