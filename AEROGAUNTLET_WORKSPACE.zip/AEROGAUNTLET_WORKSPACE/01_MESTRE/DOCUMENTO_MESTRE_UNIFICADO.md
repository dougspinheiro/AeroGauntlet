<!-- Path: 01_MESTRE/DOCUMENTO_MESTRE_UNIFICADO.md
     Rank: Lieutenant Colonel
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Unified Master Design Document

## 1. Identity

AeroGauntlet is a virtual-reality aerial combat simulator built around readable piloting, tactical decisions, and recognizable aircraft. The player flies missions across four authorized eras: WW1, WW2, Cold War, and Modern. The core experience is aircraft mastery, energy management, situational awareness, and objective completion under pressure.

The primary platform is standalone Meta Quest 2. Desktop input is a development fallback and cannot substitute for headset acceptance. The product is designed for focused sessions while preserving cockpit presence, clear feedback, and predictable controls.

Every aircraft, weapon, mission, visual treatment, and interface element must communicate its era. Content must not introduce systems that contradict the historical and commercial contract.

## 2. Principles

Stable performance is a design constraint. The target is sustained 72 FPS on Meta Quest 2, with an internal 10–11 ms frame budget and early load reduction when measurements approach the limit. Average frame time alone is insufficient; spikes and thermal behavior must also be evaluated.

VR comfort, era authenticity, accessibility, and legibility govern camera behavior, HUD density, audio priority, and difficulty. Critical threats must remain visible, and optional effects must never obscure flight or combat information.

Evidence, Day Zero, and the Real Validation Gate govern production. Untested work remains unvalidated; risky changes require reproducible measurements, explicit acceptance criteria, and a traceable result before release.

## 3. Technical targets

The engine baseline is Godot 4.7.2 and the primary deployment target is standalone Meta Quest 2. The 72 FPS target corresponds to approximately 13.89 ms per frame, while the stricter internal 10–11 ms budget reserves headroom for runtime variability.

Operational targets are CPU 4–5 ms, GPU 5–6 ms, VRAM no more than 2.8 GB, and approximately 110 draw calls. These are engineering budgets to measure, not claims that the current project already meets them.

Record headset, build, scene, resolution, aircraft count, viewing distance, temperature state, and measurement method. Optimization without a reproducible profile is not accepted as evidence.

## 4. Architecture

Use a flat Godot project layout: `scripts/`, `assets/models/`, `assets/shaders/`, and `tests/`. Folder names and identifiers remain English; each script has one primary responsibility and explicit dependencies.

The planetary terrain system uses Chunked LOD Planet Cuberact under MIT terms. Preserve required license notices and isolate third-party integration behind documented interfaces so terrain code does not spread throughout gameplay systems.

Data Resources define content; scene nodes handle presentation and interaction; global services coordinate session state. Avoid circular dependencies, oversized singletons, and direct cross-system mutation without a contract.

## 5. Production cycle

Production advances through specification, minimal implementation, static checks, automated tests, headset tests, profiling, and documented acceptance. Each gate has objective entry and exit criteria, a responsible owner, and an artifact that can be inspected.

The Builder-Critic cycle separates implementation from adversarial review. The Builder provides a reproducible artifact; the Critic checks constitutional compliance, defects, regressions, performance evidence, and missing tests. A failed gate blocks progression.

The Gauntlet Loop combines syntax scanning, headless tests, stress tests, and occlusion profiling. Every report identifies the build or commit, environment, command, result, failure evidence, and next action.

## 6. Data planning

`PlaneData` contains `id`, `name`, `era`, `faction`, `superclasse`, `mass`, `thrust`, `lift`, `drag`, `stall`, `yaw_authority`, and `unlock_cost_credits`. IDs are stable machine identifiers; display names are localized separately. Validate units, ranges, and required fields at load time.

`EnemyData` stores behavior class, detection parameters, aggression, maneuver tolerance, engagement limits, and squad composition. Each parameter requires a bounded range, a safe default, and tests for missing or malformed data.

`WeaponData` defines type, range, velocity, rate of fire, damage, ammunition, dispersion, guidance behavior, and era restrictions. `MissionData` defines objectives, theater, success and failure conditions, allowed aircraft, enemy composition, rewards, and localization keys.

## 7. Procedural generation

Procedural generation creates terrain variation, points of interest, routes, and mission variants from reproducible seeds. Equivalent seeds and data should produce equivalent results within documented tolerances.

Generation must respect geography and era, avoid impossible collisions, preserve playable areas, and guarantee navigable routes and objective visibility. Essential mission progression cannot depend solely on randomness.

Stream chunks by distance and gameplay relevance under explicit memory ceilings. Record generation time, active chunk count, object count, placement failures, and seed values so defects can be reproduced.

## 8. Shaders

The initial shader set contains eight families: terrain, water where needed, sky, clouds, aircraft lighting, cockpit glass, weapon effects, and interface indicators. Every shader has a defined purpose and GPU budget.

Declare uniforms at the top of each shader with stable names, types, defaults, and valid ranges. Materials must not rely on fragile implicit values; distant objects and constrained devices need reduced-cost variants.

Validate shader cost and visual stability on Quest 2, including aliasing, transparency sorting, overdraw, and temporal artifacts. Optional effects may be disabled before frame pacing is compromised.

## 9. Autoloads

Register autoloads in this exact order: `WorldManager` → `GameStateManager` → `SaveSystem` → `InputManager` → `PerformanceMonitor`. Dependencies must target services already initialized or use an explicit deferred initialization contract.

`WorldManager` owns world loading; `GameStateManager` owns session state and transitions; `SaveSystem` persists progress; `InputManager` normalizes input sources; `PerformanceMonitor` collects performance data without blocking the frame.

Each service requires a lifecycle contract and focused tests. Startup must fail clearly when a mandatory dependency is missing. Monitoring must not create circular dependencies or materially perturb the measurements it collects.

## 10. VR

The rendered viewpoint follows the real headset pose and must not add artificial head motion. Cockpit interactions use comfortable reach, tolerant hit areas, and clear visual or haptic feedback when supported.

Menus must not require prolonged uncomfortable posture. Text needs adequate contrast, angular size, and viewing distance. Comfort options include recentering, height adjustment, seated mode, and mitigation for artificial acceleration.

Test long sessions, scene transitions, tracking interruption, recovery, and controller loss. Core interaction must remain understandable with supported controllers and must not depend on difficult gestures alone.

## 11. Flight model

The conceptual force sum is `F_total = thrust + drag + lift + gravity + wind`, implemented as a vector sum in the appropriate reference frame. Propulsion, aerodynamic forces, gravity, and environmental disturbance remain separately measurable.

Fixed-wing dynamics model speed-dependent lift, angle of attack, drag, stall, pitch/roll/yaw authority, and aircraft-specific limits. Coefficients are calibrated by aircraft class and documented as gameplay approximations rather than certified flight simulation.

Rotary-wing dynamics model collective pitch, cyclic control, anti-torque, rotor torque, translational lift, simplified autorotation where appropriate, and ground effect. Both regimes share time integration but use distinct lift and control logic.

## 12. Combat

Combat emphasizes range, energy, orientation, firing windows, and aircraft condition. Weapon behavior and damage vary by era and platform, with clear feedback for hits, misses, and incoming threats.

Loadouts must match aircraft data and mission rules. Ammunition, rate of fire, reload behavior, and guidance limits belong in `WeaponData`, not duplicated constants in scripts.

Balance must preserve meaningful trade-offs. Later-era equipment must not become universally superior in every scenario, and target selection must remain readable in VR.

## 13. AI

Enemy aircraft use bounded state machines such as PATROL, CHASE, ATTACK, EVADE, and RETURN. State transitions require explicit conditions, cooldowns, and exit paths to prevent oscillation.

Budget decision-making per agent and stagger expensive sensing or planning. Use simpler updates for distant units, deterministic behavior where practical, and graceful degradation when the encounter exceeds its budget.

Debug tools expose current state, target, decision reason, and transition history. Tests cover unreachable targets, depleted weapons, damaged aircraft, mission end, and return-to-base behavior.

## 14. Missions

Each mission defines a briefing, theater, era, available aircraft, objectives, failure conditions, enemy composition, and reward. Objectives must be observable and communicated through HUD, audio, or briefing text.

Mission data remains separate from execution logic so content can be validated without launching a full scene. Success and failure paths must account for destroyed targets, player retreat, time limits, and loss of required assets.

Tutorial and campaign missions teach one or two mechanics at a time, then combine them. Rewards use gameplay credits and must not bypass the single-purchase economy.

## 15. World

World scale supports navigation, combat readability, and comfortable VR perception. Distances, altitude, landmarks, and weapon ranges use consistent units and documented conversion points.

Landmarks and navigation aids provide orientation without covering the horizon or obscuring threats. Terrain composition must support mission goals and chunk streaming boundaries.

World content is era-aware and avoids visual contradictions. Streaming transitions must not cause visible popping near the player or remove mission-critical geometry.

## 16. Instruments

Cockpit instruments prioritize airspeed, altitude, heading, attitude, engine state, weapon status, and immediate threats according to aircraft role and era.

Instrument behavior should respond to simulated state, use consistent units, and remain readable at normal headset resolution. Redundant displays must not disagree without a deliberate modeled fault.

Validate instruments during day, night, high workload, and damage states. Use world-space text sparingly and keep critical values legible without forcing uncomfortable head movement.

## 17. Catalog

The aircraft catalog contains 321 source IDs from manilov.ap. The canonical superclasses are `FighterAircraft`, `RotaryWingAircraft`, and `HeavySupportAircraft`.

Each entry records source ID, URL, canonical ID, era, superclass, license verification, content hash, ingestion state, and notes. Example canonical IDs include `bf109_g6` and `mi24_hind_f`; naming is lowercase snake_case.

No model is considered distributable until provenance, license terms, technical suitability, and project integration are recorded. Unknown license status remains blocked, not implicitly approved.

## 18. Cockpits

Cockpits communicate aircraft identity and operational role while protecting player comfort. Controls must have stable interaction zones and feedback that remains legible under turbulence and combat workload.

Player aircraft may retain functional cockpit geometry; AI-only aircraft should omit interior meshes when they are never visible, reducing memory and rendering cost. Use shared materials and LODs where visual quality permits.

Cockpit validation covers scale, reach, occlusion, instrument readability, hand/controller alignment, and seated posture. Any animation must avoid visual conflict with tracked headset movement.

## 19. 3D asset contract

Deliver models in an agreed interchange format, preferably GLB, with consistent forward axis, scale, origin, naming, and material assignment. Include source attribution and license evidence alongside every imported asset.

Separate render meshes, collision proxies, cockpit interiors, and optional details. Remove hidden geometry, normalize transforms, inspect normals, and ensure materials use mobile-compatible settings.

Acceptance records polygon count, material count, texture dimensions, compressed memory, LOD thresholds, silhouette comparison, and any known defects. A visually plausible mesh is not automatically optimized or licensed.

## 20. Geometry budget

Geometry budgets are assigned by distance and gameplay relevance rather than a single global polygon target. Player aircraft receive the highest detail; distant enemies and background traffic use progressively simpler meshes.

LOD transitions must preserve silhouette, orientation cues, weapon attachment points, and collision behavior. Avoid material proliferation and transparent surfaces that create expensive overdraw.

Measure worst-case scenes with representative aircraft density. Geometry reductions are accepted only when performance improves and required visual cues remain intact.

## 21. Implementation phases

Phase 1: create and open a minimal Godot project. Phase 2: establish folder and naming conventions. Phase 3: implement the five autoloads. Phase 4: define data Resources. Phase 5: build input abstraction.

Phase 6: implement fixed-wing physics. Phase 7: implement rotary-wing physics. Phase 8: establish a controllable aircraft scene. Phase 9: add weapon data and firing. Phase 10: implement enemy state machines.

Phase 11: create a basic mission loop. Phase 12: integrate terrain chunks. Phase 13: ingest and optimize aircraft assets. Phase 14: add VR cockpit interaction. Phase 15: implement save/load. Phase 16: run automated and headset QA. Phase 17: profile, package, and pass the release gate.

## 22. Post-MVP expansions

Post-MVP work may add new mission packs, optional historical aircraft collections, campaign depth, and supported platform improvements after core acceptance.

Any DLC must be optional content sold transparently and cannot provide competitive power unavailable through ordinary gameplay credits. Core safety, performance, accessibility, and save integrity remain part of the base product.

Expansion proposals require scope approval, asset provenance, production estimates, test plans, and a clear statement of compatibility with existing saves.

## 23. Progression

Gameplay credits are earned through mission completion, objectives, survival, and optional performance criteria. Reward rules must be visible before mission launch and consistent across difficulty settings.

Aircraft unlock costs live in data and are balanced against mission rewards. The 321-aircraft catalog is an intended catalog target; entries remain unavailable until asset and license checks pass.

The economy has no paid power shortcuts. Avoid opaque grind, irreversible accidental purchases, and rewards that require inaccessible control schemes. Progression telemetry should measure friction without collecting unnecessary personal data.

## 24. Save system

Save data uses a documented schema with an explicit schema identifier, required fields, defaults, and validation. Store progression, credits, unlocked aircraft, settings, and resumable campaign state only where needed.

Writes should be atomic or recoverable, with a safe fallback when storage is interrupted. Validate input before applying it to live state and handle missing, malformed, or incompatible files without crashing.

Protect local saves against casual tampering where practical, but do not promise cryptographic guarantees unsupported by the implementation. Keep secrets out of saves and test backup, restore, and corruption paths.

## 25. Replay

Replay records a bounded set of simulation inputs and events needed to reconstruct a session or review key moments. Define whether the system stores deterministic inputs, sampled state, or both.

Record build identity, mission seed, aircraft configuration, and relevant simulation parameters. Limit storage size and avoid capturing personal information unrelated to gameplay.

Replay correctness is tested against known scenarios with tolerances for physics and timing. If exact determinism is not guaranteed, label the feature as a review replay rather than an authoritative simulation record.

## 26. Multiplayer

Multiplayer is not an MVP dependency. Any future network mode requires a separate architecture, threat model, synchronization design, and platform feasibility assessment.

A proposal must define authority, latency tolerance, replication scope, session lifecycle, reconnect behavior, and anti-cheat boundaries before implementation begins.

Network features cannot compromise single-player reliability, frame budgets, privacy, or the single-purchase economy. No schedule or capability is promised until a dedicated gate is approved.

## 27. QA

QA includes unit, integration, smoke, regression, stress, headset, and build acceptance tests. Headless Gauntlet Loop results are mandatory for automated checks but do not replace visual and performance testing on the target device.

Every defect includes reproduction steps, expected and observed results, logs, affected subsystem, severity, and a regression test when feasible. A passing test is evidence only for the environment and coverage actually exercised.

The release candidate must pass syntax scanning, data validation, crash-log review, representative stress tests, and frame-budget checks. Any unexplained crash or critical performance regression blocks release.

## 28. Telemetry

Performance telemetry captures frame time, CPU/GPU timings where available, memory, draw calls, active aircraft, chunk counts, and loading stalls. Use aggregate metrics and bounded local logs by default.

Every measurement includes build identity, scene, device state, duration, and capture method. Sampling overhead must be measured and excluded or accounted for in final performance claims.

Do not collect identifiers or behavioral data without a defined purpose, disclosure, retention rule, and applicable consent. Telemetry is diagnostic evidence, not a substitute for reproducible QA.

## 29. Localization

Player-facing strings are supported in Brazilian Portuguese and English. Use Godot `tr()` keys, stable identifiers, and translation tables rather than hard-coded text in gameplay scripts.

Plan for pluralization, placeholders, font coverage, line expansion, controller labels, subtitles, and accessibility settings. Technical identifiers and Godot folder names remain English.

Test all menus and briefings at headset viewing distance in both languages. Missing keys must have a safe fallback and be detected by automated checks.

## 30. Security

Apply data minimization, safe local storage, dependency review, and clear permission boundaries. LGPD refers to Brazil’s General Data Protection Law; privacy decisions must be assessed against applicable requirements rather than treated as a label alone.

Validate save files and imported data before use. Do not execute content from assets, expose credentials in logs, or trust unverified catalog metadata. Preserve license records and provenance for all third-party assets.

Document data collected, purpose, storage location, retention, deletion behavior, and user-facing disclosure. Security controls must be tested and claims must match the actual implementation.

## 31. Distribution

The base product uses a single-purchase model with gameplay-credit unlocks. Optional DLC may be considered after MVP; competitive advantages must not be sold and core progression cannot be pay-to-win.

Build targets include Meta Store and SideQuest for Quest, with Steam considered for desktop distribution. Each channel has distinct packaging, policy, metadata, signing, and validation requirements.

Release artifacts must be signed where required, carry the correct package identity, include third-party notices, and pass clean-install, startup, save, and headset performance checks.

## 32. Definition of Done

A feature is done only when its scope and acceptance criteria are documented, implementation is present, and relevant automated tests pass. Required code and data must be committed to the intended workspace paths with no hidden local dependency.

Static checks, error logs, and known limitations are reviewed. Target-device features require real Quest 2 evidence; desktop-only execution cannot validate headset performance, comfort, or OpenXR behavior.

The handoff includes exact paths, test commands, measured results, screenshots or logs where relevant, and remaining gaps. Status remains PLANNED or ACTIVE until evidence supports VALIDATED; the Real Validation Gate is mandatory.
