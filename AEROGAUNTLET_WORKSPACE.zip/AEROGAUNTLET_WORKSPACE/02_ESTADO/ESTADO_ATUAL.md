<!-- Path: 02_ESTADO/ESTADO_ATUAL.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: ACTIVE -->

# Current State — Evidence-Based Inventory

Only artifacts that open and run in the declared Godot environment with reproducible evidence may be marked `VALIDATED`. The initial state is zero validated subsystems; documentation describes intended work, not completed implementation.

| Subsystem | File | LOC | Actual status | Evidence | Gap |
|---|---|---:|---|---|---|
| Godot project | `08_GAME/PROJECT/` | 0 | NOT VALIDATED | No project-open evidence attached | Create and open a minimal project |
| Terrain | Pending | 0 | NOT STARTED | None | Integrate Chunked LOD Planet Cuberact MIT |
| Autoloads | Pending | 0 | NOT STARTED | None | Implement five autoloads in canonical order |
| Save System | Pending | 0 | NOT STARTED | None | Define a versioned schema and recovery behavior |
| Localization | Pending | 0 | NOT STARTED | None | Create PT-BR and EN translation tables |
| Flight model | Pending | 0 | NOT STARTED | None | Implement and test fixed-wing and rotary-wing models |
| Aircraft catalog | `07_ASSETS/CATALOGO_MANILOV.md` | 0 | NOT STARTED | No ingested IDs verified | Register 321 source IDs with provenance and license state |
| QA loop | `08_GAME/PROJECT/tests/` | 0 | NOT STARTED | No headless run log | Implement automation and retain logs |

Status values are NOT STARTED, ACTIVE, BLOCKED, NOT VALIDATED, and VALIDATED. A status change requires date, owner, test command, environment, result, and evidence location. Estimates and design descriptions do not count as implementation evidence.
