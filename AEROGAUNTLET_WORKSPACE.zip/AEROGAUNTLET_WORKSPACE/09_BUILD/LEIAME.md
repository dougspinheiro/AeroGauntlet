<!-- Path: 09_BUILD/LEIAME.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Build and Release

This directory contains build acceptance requirements and packaging evidence. Keep signing, OpenXR configuration, package identity, device validation, performance measurements, and distribution-channel checks traceable to a specific build artifact.
