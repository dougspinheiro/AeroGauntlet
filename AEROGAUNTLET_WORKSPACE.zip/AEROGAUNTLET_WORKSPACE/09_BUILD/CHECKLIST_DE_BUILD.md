<!-- Path: 09_BUILD/CHECKLIST_DE_BUILD.md
     Rank: Captain
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: ACTIVE -->

# Build Checklist

- [ ] Confirm Godot 4.7.2 and the intended project path.
- [ ] Run syntax scan: no `//` comments in `.gd` files.
- [ ] Confirm `res` is not used as a variable scope.
- [ ] Inspect mutation boundaries and required `.duplicate()` calls.
- [ ] Run headless Gauntlet Loop and inspect the crash report.
- [ ] Validate asset license records and third-party notices.
- [ ] Measure CPU 4–5 ms, GPU 5–6 ms, VRAM ≤ 2.8 GB, and approximately 110 draw calls in representative scenes.
- [ ] Confirm sustained 72 FPS target and internal 10–11 ms budget on Meta Quest 2.
- [ ] Sign the APK as required and verify package identity `com.aerogauntlet`.
- [ ] Test clean install, startup, controls, save/load, localization, and exit.
- [ ] Attach build artifact identity, device, commands, logs, and measured results.

A checklist item is complete only when evidence is recorded. Any critical crash, licensing uncertainty, failed syntax check, or unexplained frame-budget breach blocks distribution.
