<!-- Path: 07_ASSETS/LEIAME.md
     Rank: Lieutenant
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: FOUNDATIONAL -->

# Asset Workspace

This directory owns the aircraft catalog and ingestion pipeline. Store source provenance, license evidence, hashes, optimization measurements, LOD metadata, and integration state. No asset enters a distributable build until rights and technical acceptance are recorded.
