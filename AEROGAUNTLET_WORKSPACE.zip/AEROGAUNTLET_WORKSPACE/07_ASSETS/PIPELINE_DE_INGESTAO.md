<!-- Path: 07_ASSETS/PIPELINE_DE_INGESTAO.md
     Rank: Major
     Subordination: Operational Constitution (supreme law) + Human (supreme command)
     Status: ACTIVE -->

# Asset Ingestion Pipeline

## State model
Each asset moves through NOT DOWNLOADED → DOWNLOADED → OPTIMIZED → INTEGRATED. BLOCKED may be assigned whenever licensing, provenance, geometry, texture, or compatibility is unresolved. State changes require an owner, timestamp, evidence path, and reason.

## Validation
Capture source ID, URL, source filename, license terms, attribution requirements, retrieval date, and source hash. Confirm commercial redistribution rights before integration. A public model page or successful download does not prove that the asset may ship in a paid game.

## Optimization
Normalize scale, orientation, transforms, origins, normals, material naming, and collision proxies. Remove invisible geometry and cockpit interiors from AI-only aircraft where they cannot be seen. Generate distance-based LODs and enable backface culling only when mesh winding and material requirements permit. Compress textures for mobile and record memory cost.

## Integration acceptance
Verify the model opens in Godot, materials render correctly, LOD transitions preserve silhouette, collision behavior is appropriate, and the aircraft is linked to valid PlaneData. Record polygon count, material count, texture memory, file size, hash, and test evidence. Unknown license or unresolved visual defects keep the item blocked.
